const t="https://jobsage.co.uk",i="";async function e(){return{env:"production",devOrigin:""}}function s(n){return t}function a(n){return`${s()}/api`}export{i as D,a,s as b,e as g};
