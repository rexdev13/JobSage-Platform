import { useEffect, useRef, useState } from "react";
import { useAuth } from "@workspace/auth-web";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, Button, PageTransition } from "@/components/ui-enhanced";
import {
  listMatchedRoles,
  useListMyApplications,
  useGenerateCoverLetter,
  useGetMyProfile,
  useUpsertMyProfile,
  useGetMyMatches,
  useDismissMatch,
  useListMyDocuments,
  getListMyApplicationsQueryKey,
  getListMatchedRolesQueryKey,
  getGetMyProfileQueryKey,
  getGetMyMatchesQueryKey,
  type MatchedRole,
  type ApplicationList,
  type CandidateMatchItem,
  type CandidateMatchList,
} from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { SmartApplyModal } from "@/components/SmartApplyModal";
import { GapAnalysisSheet } from "@/components/GapAnalysisSheet";
import { FavoriteButton } from "@/components/FavoriteButton";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  Briefcase,
  MapPin,
  Building2,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Star,
  ChevronDown,
  ChevronUp,
  X,
  Megaphone,
  ClipboardList,
  Globe,
  Mail,
  Phone,
  TrendingUp,
  Search,
  BadgeCheck,
  ShieldCheck,
  Clock,
  DollarSign,
  Sparkles,
  FileText,
  Copy,
  Loader2,
  Zap,
  Medal,
  Info,
  Send,
  Calendar,
  CalendarDays,
  ExternalLink,
} from "lucide-react";
import { DisclaimerBanner } from "@/components/ui/DisclaimerBanner";

const OPPORTUNITIES_TIMEOUT_MS = 15_000;

async function listMatchedRolesWithTimeout(
  source: "job_board" | "company_site" | undefined,
  parentSignal: AbortSignal,
) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort("Opportunities request timed out"), OPPORTUNITIES_TIMEOUT_MS);
  const abortFromParent = () => controller.abort(parentSignal.reason);
  parentSignal.addEventListener("abort", abortFromParent, { once: true });
  try {
    return await listMatchedRoles({ source }, { signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
    parentSignal.removeEventListener("abort", abortFromParent);
  }
}
import {
  SmartApplyExtensionBanner,
  SmartApplyExtensionNudge,
  shouldShowExtensionNudge,
  useExtensionGate,
} from "@/components/SmartApplyExtensionPrompt";
import { motion, AnimatePresence } from "framer-motion";
import {
  filterOpportunities,
  canSendCvForVacancy,
  getOpportunityApplyAction,
  groupRankedOpportunities,
  hasRegionOverlap,
  shouldShowOpportunityApplyActions,
  shouldShowOnSendCvTab,
  shouldShowSendCv,
  UK_REGIONS,
} from "@/lib/opportunityFilters";
import { checkApplyLinkInBackground } from "@/lib/vacancyApply";
import { normalizeWebsiteUrl, openTrackedOutbound } from "@/lib/trackedOutbound";

type Tab = "board" | "employers" | "sendcv";

function AiScoreBadge({ score }: { score: number }) {
  const cls =
    score >= 80
      ? "bg-emerald-100 text-emerald-800 border-emerald-200"
      : score >= 55
      ? "bg-blue-100 text-blue-800 border-blue-200"
      : "bg-muted text-muted-foreground border-border";
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${cls}`}>
      <Zap className="w-3 h-3" /> {score}% match
    </span>
  );
}

function BestMatchesStrip({
  matchesData,
  matchesLoading,
  appliedRoleIds,
  localDismissedIds,
  onSmartApply,
  onOpenApplication,
  onDismiss,
  sourceType,
}: {
  matchesData: CandidateMatchList | undefined;
  matchesLoading: boolean;
  appliedRoleIds: number[];
  localDismissedIds: Set<number>;
  onSmartApply: (roleId: number, roleTitle: string) => void;
  onOpenApplication: (url: string, match: CandidateMatchItem, vacancyIntent: boolean) => void;
  onDismiss: (roleId: number) => void;
  sourceType: "job_board" | "company_site";
}) {
  const [, setLocation] = useLocation();
  const resultsSectionId = sourceType === "company_site" ? "company-site-section" : "job-board-section";

  const serverDismissed = new Set(matchesData?.dismissedRoleIds ?? []);
  const effectiveDismissed = new Set([...serverDismissed, ...localDismissedIds]);

  const allMatches: CandidateMatchItem[] = matchesData?.matches ?? [];
  const visibleQueue = allMatches
    .filter((m) => !effectiveDismissed.has(m.roleId) && !appliedRoleIds.includes(m.roleId))
    .slice(0, 3);

  const totalAvailable = (matchesData?.totalCount ?? allMatches.length) - localDismissedIds.size;

  if (matchesLoading) {
    return (
      <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/3 to-accent/3 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-4 h-4 text-primary animate-pulse" />
          <span className="text-sm font-semibold text-foreground">Your Best Matches Right Now</span>
          <span className="text-xs text-muted-foreground ml-1">AI scoring…</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-28 rounded-xl bg-muted/50 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (!matchesData || allMatches.length === 0) return null;

  if (visibleQueue.length === 0) {
    return (
      <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/3 to-accent/3 p-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
          <p className="text-sm font-medium text-foreground">You&apos;ve reviewed all your top matches — well done!</p>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={() => document.getElementById(resultsSectionId)?.scrollIntoView({ behavior: "smooth" })}
        >
          See all roles
        </Button>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/3 to-accent/3 p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">Your Best Matches Right Now</h2>
          <span className="px-1.5 py-0.5 text-xs rounded bg-primary/10 text-primary font-medium">AI</span>
        </div>
        <p className="text-xs text-muted-foreground">{matchesData.cached ? "Updated today" : "Just scored"}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <AnimatePresence mode="popLayout">
          {visibleQueue.map((match) => (
            <motion.div
              key={match.roleId}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-background rounded-xl border border-border p-4 flex flex-col gap-2 shadow-sm"
            >
              <div className="absolute top-2 right-2 flex items-center gap-0.5">
                <FavoriteButton vacancyId={match.roleId} className="p-1" />
                <button
                  className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted transition-colors"
                  onClick={() => onDismiss(match.roleId)}
                  title="Dismiss"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-start gap-2 pr-14">
                <AiScoreBadge score={match.aiScore} />
              </div>

              <p className="text-xs text-muted-foreground italic leading-snug">&ldquo;{match.aiExplanation}&rdquo;</p>
              {match.matchReason && (
                <p className="text-xs text-primary/80 font-medium leading-snug">{match.matchReason}</p>
              )}

              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground leading-tight line-clamp-2">{match.title}</p>
                <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{match.employer}</span>
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{match.location}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-auto pt-1">
                {match.applyUrl && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 min-w-[9rem] text-xs h-8 gap-1"
                    onClick={() => onOpenApplication(normalizeWebsiteUrl(match.applyUrl!), match, true)}
                  >
                    <ExternalLink className="w-3 h-3" /> {sourceType === "job_board" ? "Apply Via Job Board" : "Apply on company's website"}
                  </Button>
                )}
                {match.isEligible ? (
                  <Button
                    size="sm"
                    className="flex-1 min-w-[9rem] text-xs h-8 gap-1"
                    onClick={() => onSmartApply(match.roleId, match.title)}
                  >
                    <Sparkles className="w-3 h-3" /> Smart Apply
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 min-w-[9rem] text-xs h-8 gap-1 text-amber-700 border-amber-200"
                    onClick={() => setLocation("/path")}
                  >
                    View Path <ArrowRight className="w-3 h-3" />
                  </Button>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="flex items-center justify-between pt-1">
        <p className="text-xs text-muted-foreground">
          Showing top 3 of {totalAvailable} AI-ranked matches
        </p>
        <button
          className="text-xs text-primary font-medium flex items-center gap-1 hover:underline"
          onClick={() => document.getElementById(resultsSectionId)?.scrollIntoView({ behavior: "smooth" })}
        >
          See all {totalAvailable} matches below <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

function SafeguardingBadge({
  safeguarding,
}: {
  safeguarding: MatchedRole["safeguarding"];
}) {
  const statuses = [safeguarding.dbsStatus, safeguarding.safeguardingStatus];
  if (
    safeguarding.requiredDbsClearanceLevel == null &&
    safeguarding.requiredSafeguardingLevel == null
  ) {
    return null;
  }
  const missing = statuses.includes("missing");
  const needsProfile = statuses.includes("unknown_needs_profile");
  const cls = missing
    ? "bg-red-100 text-red-700"
    : needsProfile
      ? "bg-amber-100 text-amber-800"
      : "bg-emerald-100 text-emerald-800";
  const label = missing ? "DBS / safeguarding: gap" : needsProfile ? "DBS / safeguarding: update profile" : "DBS / safeguarding: stated requirements met";
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${cls}`}>
      <ShieldCheck className="w-3 h-3" /> {label}
    </span>
  );
}

function MatchScoreBadge({ score }: { score: number }) {
  const color =
    score >= 80 ? "bg-emerald-100 text-emerald-800" : score >= 50 ? "bg-blue-100 text-blue-800" : "bg-muted text-muted-foreground";
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold ${color}`}>
      <Star className="w-3 h-3" /> {score}% match
    </span>
  );
}

function LicensedSponsorBadge({ licensedSponsor }: { licensedSponsor?: boolean }) {
  if (!licensedSponsor) return null;
  return (
    <span
      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200"
      title="This employer appears on the Home Office sponsor register. This job may or may not offer sponsorship — check the employer's advert."
    >
      <ShieldCheck className="w-3 h-3" /> Licensed Sponsor
    </span>
  );
}

function RoleDetailModal({ item, appliedRoleIds, onClose, aiScore }: {
  item: MatchedRole;
  appliedRoleIds: number[];
  onClose: () => void;
  aiScore?: number;
}) {
  const [, setLocation] = useLocation();
  const { role, isEligible, matchScore, eligibilityGaps, safeguarding } = item;
  const applied = appliedRoleIds.includes(role.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="relative bg-background rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto z-10"
      >
        <div className={`h-2 rounded-t-2xl ${isEligible ? "bg-gradient-to-r from-emerald-500 to-green-400" : "bg-gradient-to-r from-amber-400 to-orange-400"}`} />
        <div className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-foreground">{role.title}</h2>
              <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Building2 className="w-3.5 h-3.5" /> {role.employer}</span>
                <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {role.location}</span>
              </div>
            </div>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted transition-colors ml-2">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {isEligible ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                <BadgeCheck className="w-3.5 h-3.5" /> Eligible Now
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
                <Clock className="w-3.5 h-3.5" /> Not Yet Eligible
              </span>
            )}
            {aiScore != null ? <AiScoreBadge score={aiScore} /> : <MatchScoreBadge score={matchScore} />}
            <LicensedSponsorBadge licensedSponsor={role.licensedSponsor} />
            <SafeguardingBadge safeguarding={safeguarding} />
          </div>

          <div className="space-y-3 mb-5">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="p-3 rounded-lg bg-muted/40">
                <p className="text-xs text-muted-foreground mb-0.5">Profession category</p>
                <p className="font-semibold">{role.opportunityCategory ?? role.regulator ?? "Professional"}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/40">
                <p className="text-xs text-muted-foreground mb-0.5">Required Registration</p>
                <p className="font-semibold text-xs leading-tight">{role.requiredRegistration}</p>
              </div>
            </div>
          </div>

          {!isEligible && eligibilityGaps && eligibilityGaps.length > 0 && (
            <div className="mb-4 p-4 rounded-xl bg-amber-50 border border-amber-200">
              <p className="text-xs font-semibold text-amber-800 mb-2 uppercase tracking-wide">Why you&apos;re not yet eligible</p>
              <ul className="space-y-1.5">
                {eligibilityGaps.map((gap, i) => (
                  <li key={i} className="text-xs text-amber-800 flex items-start gap-2">
                    <span className="text-amber-500 mt-0.5">•</span> {gap}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {applied && (
            <div className="mb-3 flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-200 text-sm font-semibold text-emerald-800">
              <CheckCircle2 className="w-4 h-4" /> Applied
            </div>
          )}
          {!applied && (
            <p className="mb-3 text-xs text-muted-foreground">
              Use Smart Apply or send your CV to track this role — clicking through to the employer&apos;s site just opens it in a new tab.
            </p>
          )}
          {!isEligible && (
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => { onClose(); setLocation("/path"); }}
              >
                View Remediation Path <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function useCoverLetterStream() {
  const [text, setText] = useState("");
  const [disclaimer, setDisclaimer] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setText("");
    setDisclaimer("");
    setStreaming(false);
    setDone(false);
    setError(null);
  }

  async function generate(payload: {
    jobTitle: string;
    employer: string;
    location?: string | null;
    regulator?: string | null;
    jobDescription?: string | null;
    roleId?: number;
  }) {
    reset();
    setStreaming(true);
    const base = import.meta.env.BASE_URL.replace(/\/$/, "");
    try {
      const resp = await fetch(`${base}/api/cover-letter/generate-stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(payload),
      });
      if (!resp.ok || !resp.body) {
        setError("Failed to start generation. Please try again.");
        setStreaming(false);
        return;
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done: rdDone, value } = await reader.read();
        if (rdDone) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const parsed = JSON.parse(line.slice(6)) as { text?: string; done?: boolean; disclaimer?: string; error?: string };
            if (parsed.error) { setError(parsed.error); setStreaming(false); return; }
            if (parsed.text) setText((prev) => prev + parsed.text);
            if (parsed.done) {
              setDisclaimer(parsed.disclaimer ?? "");
              setDone(true);
              setStreaming(false);
            }
          } catch { /* ignore parse errors */ }
        }
      }
    } catch {
      setError("Network error. Please try again.");
      setStreaming(false);
    }
  }

  return { text, setText, disclaimer, streaming, done, error, generate, reset };
}

function CoverLetterModal({
  role,
  onClose,
}: {
  role: {
    id: number;
    title: string;
    employer: string;
    location: string;
    regulator?: string | null;
    opportunityCategory?: string | null;
    description?: string | null;
  };
  onClose: () => void;
}) {
  const { toast } = useToast();
  const stream = useCoverLetterStream();
  const [editableText, setEditableText] = useState("");
  const [copied, setCopied] = useState(false);

  // Sync editable text while streaming
  if (stream.streaming && stream.text !== editableText) {
    setEditableText(stream.text);
  }

  function handleGenerate() {
    stream.generate({
      jobTitle: role.title,
      employer: role.employer,
      location: role.location,
      regulator: role.opportunityCategory ?? role.regulator ?? "Professional",
      jobDescription: role.description ?? null,
      roleId: role.id,
    }).catch(() => toast({ title: "Error", description: "Failed to generate cover letter.", variant: "destructive" }));
  }

  function handleCopy() {
    const content = stream.done ? editableText : stream.text;
    if (!content) return;
    navigator.clipboard.writeText(content).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function handleDownload() {
    const content = stream.done ? editableText : stream.text;
    if (!content) return;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cover-letter-${role.employer.replace(/\s+/g, "-").toLowerCase()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const hasContent = stream.text.length > 0 || editableText.length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 40 }}
        className="relative bg-background border border-border rounded-2xl shadow-2xl w-full max-w-2xl mx-4 max-h-[90vh] flex flex-col overflow-hidden"
      >
        <div className="flex items-center justify-between p-5 border-b border-border">
          <div>
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" /> Cover Letter Generator
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              {role.title} · {role.employer}
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-accent transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {!hasContent && !stream.streaming && !stream.error && (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-primary" />
              </div>
              <h4 className="text-base font-semibold text-foreground mb-2">Generate a tailored cover letter</h4>
              <p className="text-sm text-muted-foreground mb-6 max-w-md mx-auto">
                AI will write a personalised cover letter for this role based on your profile and any CV documents you have uploaded.
              </p>
              <Button onClick={handleGenerate} className="gap-2">
                <Sparkles className="w-4 h-4" /> Generate Cover Letter
              </Button>
            </div>
          )}

          {stream.error && (
            <div className="text-center py-8">
              <p className="text-sm text-destructive mb-3">{stream.error}</p>
              <Button variant="outline" onClick={handleGenerate} className="gap-2">
                <Sparkles className="w-4 h-4" /> Try Again
              </Button>
            </div>
          )}

          {(hasContent || stream.streaming) && (
            <div className="space-y-4">
              {stream.streaming && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" />
                  Writing your cover letter…
                </div>
              )}
              <textarea
                className="w-full min-h-[340px] p-4 text-sm text-foreground leading-relaxed bg-muted/40 rounded-xl border border-border resize-y focus:outline-none focus:ring-2 focus:ring-primary/30 font-sans"
                value={stream.streaming ? stream.text : editableText}
                onChange={(e) => setEditableText(e.target.value)}
                readOnly={stream.streaming}
                placeholder="Your cover letter will appear here…"
              />
              {stream.done && stream.disclaimer && (
                <p className="text-xs text-muted-foreground border-l-2 border-primary/30 pl-3">
                  {stream.disclaimer}
                </p>
              )}
            </div>
          )}
        </div>

        <div className="p-5 border-t border-border flex items-center justify-between gap-3">
          <Button variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
          <div className="flex gap-2 flex-wrap justify-end">
            {hasContent && (
              <>
                <Button size="sm" variant="outline" onClick={handleGenerate} disabled={stream.streaming} className="gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Regenerate
                </Button>
                <Button size="sm" variant="outline" onClick={handleDownload} disabled={stream.streaming} className="gap-1.5">
                  <FileText className="w-3.5 h-3.5" /> Download .txt
                </Button>
                <Button size="sm" onClick={handleCopy} disabled={stream.streaming} className="gap-1.5">
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? "Copied!" : "Copy"}
                </Button>
              </>
            )}
            {!hasContent && !stream.streaming && (
              <Button size="sm" onClick={handleGenerate} className="gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Generate
              </Button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function RoleCard({
  item,
  appliedRoleIds,
  cvSentRoleIds,
  onSendCv,
  onSmartApply,
  onViewDetail,
  onCoverLetter,
  onExternalApply,
  onViewAnalysis,
  requireExtension,
  recommended,
  aiScore,
  aiScoring,
  sendCvOnly,
}: {
  item: MatchedRole;
  appliedRoleIds: number[];
  cvSentRoleIds: number[];
  onSendCv: (item: MatchedRole) => void;
  onSmartApply: (roleId: number, roleTitle: string) => void;
  onViewDetail: (item: MatchedRole) => void;
  onCoverLetter: (role: MatchedRole["role"]) => void;
  onExternalApply?: () => void;
  onViewAnalysis?: (item: MatchedRole) => void;
  requireExtension: (action: () => void) => void;
  recommended?: boolean;
  aiScore?: number;
  aiScoring?: boolean;
  sendCvOnly?: boolean;
}) {
  const [, setLocation] = useLocation();
  const { role, isEligible, matchScore, eligibilityGaps, safeguarding, contactEmail, contactPhone, contactWebsite, applyUrl, linkVerified, linkCheckedAt, matchReason } = item;
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(false);
  const [deadLink, setDeadLink] = useState(false);

  const trackAndOpen = (targetUrl: string): void => {
    void openTrackedOutbound({
      url: targetUrl,
      vacancy: {
        title: role.title,
        employer: role.employer,
        roleId: role.id,
        canonicalUrl: targetUrl,
      },
      onTracked: onExternalApply,
    });
  };

  const doApplyClick = (destinationUrl?: string): void => {
    const targetUrl = destinationUrl ?? applyUrl;
    if (!targetUrl) return;

    // Company-website fallback has no vacancy URL to health-check.
    if (destinationUrl !== undefined) {
      void openTrackedOutbound({ url: targetUrl, onTracked: onExternalApply });
      return;
    }

    // Open and record synchronously so popup blockers and health API latency
    // can never strand the candidate on a "Checking…" state.
    trackAndOpen(targetUrl);
    const base = import.meta.env.BASE_URL.replace(/\/$/, "");
    void checkApplyLinkInBackground({
      url: targetUrl,
      endpoint: `${base}/api/vacancy-link-check`,
      linkVerified: !!linkVerified,
      linkCheckedAt,
      onDead: () => {
        setDeadLink(true);
        void queryClient.invalidateQueries({ queryKey: getListMatchedRolesQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetMyMatchesQueryKey() });
      },
    });
  };

  // Gate every outbound click behind the extension check.
  const handleApplyClick = (destinationUrl?: string): void => {
    requireExtension(() => doApplyClick(destinationUrl));
  };

  const applied = appliedRoleIds.includes(role.id);
  const cvSent = cvSentRoleIds.includes(role.id);
  const hasContactDetails = !!(contactEmail || contactPhone || contactWebsite);
  const applyAction = getOpportunityApplyAction({ sourceType: role.sourceType, applyUrl, contactWebsite });

  return (
    <Card
      className={`p-5 hover:shadow-md transition-all cursor-pointer ${
        recommended
          ? "border-primary/30 bg-gradient-to-r from-primary/[0.03] to-accent/[0.03] hover:border-primary/50"
          : isEligible
          ? "border-emerald-100 hover:border-emerald-200"
          : "hover:border-border"
      }`}
      onClick={() => onViewDetail(item)}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            {recommended && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-primary/10 text-primary">
                <Medal className="w-3 h-3" /> Apply First
              </span>
            )}
            {isEligible ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                <BadgeCheck className="w-3 h-3" /> Eligible Now
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
                <Clock className="w-3 h-3" /> Not Yet Eligible
              </span>
            )}
            {aiScore != null ? <AiScoreBadge score={aiScore} /> : <MatchScoreBadge score={matchScore} />}
            {aiScore == null && aiScoring && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">
                <Zap className="w-3 h-3 animate-pulse" /> AI scoring…
              </span>
            )}
            {role.sourceType === "job_board" && role.boardName && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-100">
                {role.boardName}
              </span>
            )}
          </div>
          <h3 className="text-base font-semibold text-foreground">{role.title}</h3>
          <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground flex-wrap">
            <span className="flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5" /> {role.employer}
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" /> {role.location}
            </span>
            <span className="px-1.5 py-0.5 text-xs rounded bg-muted text-muted-foreground font-mono">
              {role.opportunityCategory ?? role.regulator ?? "Professional"}
            </span>
          </div>
          {recommended && matchReason && (
            <p className="mt-2 text-xs font-medium text-primary/80">{matchReason}</p>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
          {applied && (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
              <CheckCircle2 className="w-3 h-3" /> Applied
            </span>
          )}
          <FavoriteButton vacancyId={role.id} />
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <SafeguardingBadge safeguarding={safeguarding} />
        <LicensedSponsorBadge licensedSponsor={role.licensedSponsor} />
      </div>

      {/* Company contact row */}
      <div className="mt-3 space-y-2" onClick={(e) => e.stopPropagation()}>
        {shouldShowOpportunityApplyActions(sendCvOnly) && role.sourceType === "company_site" && applyUrl && contactWebsite && (
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); handleApplyClick(contactWebsite.startsWith("http") ? contactWebsite : `https://${contactWebsite}`); }}
            className="flex items-center gap-2 text-xs text-primary hover:underline text-left"
          >
            <Globe className="w-3.5 h-3.5 shrink-0" />
            {contactWebsite.startsWith("http") ? contactWebsite : `https://${contactWebsite}`}
            <ExternalLink className="w-3 h-3 opacity-50" />
          </button>
        )}
        {contactEmail && (
          <a
            href={`mailto:${contactEmail}`}
            className="flex items-center gap-2 text-xs text-foreground hover:text-primary"
          >
            <Mail className="w-3.5 h-3.5 text-primary shrink-0" />
            {contactEmail}
          </a>
        )}
        {contactPhone && (
          <a
            href={`tel:${contactPhone}`}
            className="flex items-center gap-2 text-xs text-foreground hover:text-primary"
          >
            <Phone className="w-3.5 h-3.5 text-primary shrink-0" />
            {contactPhone}
          </a>
        )}
        {!hasContactDetails && (
          <span className="text-xs text-muted-foreground italic">Contact details not yet available</span>
        )}
      </div>

      {eligibilityGaps && eligibilityGaps.length > 0 && (
        <div className="mt-3">
          <button
            className="text-xs text-amber-700 hover:text-amber-900 flex items-center gap-1 transition-colors"
            onClick={(e) => { e.stopPropagation(); setExpanded((v) => !v); }}
          >
            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            {expanded ? "Hide" : "See"} eligibility notes
          </button>
          {expanded && (
            <div className="mt-2 p-3 rounded-lg bg-amber-50 border border-amber-100">
              <p className="text-xs text-amber-700 font-medium mb-1.5">Advisory — you can still apply and contact this employer directly:</p>
              <ul className="space-y-1">
                {eligibilityGaps.map((gap, i) => (
                  <li key={i} className="text-xs text-amber-800 flex items-start gap-1.5">
                    <span className="text-amber-500 mt-0.5 shrink-0">•</span> {gap}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {shouldShowOpportunityApplyActions(sendCvOnly) && applyAction?.usesWebsiteFallback && !applied && (
        <div className="mt-3 flex items-center gap-2 flex-wrap" onClick={(e) => e.stopPropagation()}>
          <button
            type="button"
            onClick={() =>
              handleApplyClick(applyAction.destinationUrl)
            }
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors"
          >
            <Globe className="w-3.5 h-3.5" /> {applyAction.label}
          </button>
            <span className="text-[11px] text-muted-foreground">
             No verified vacancy link yet — this opens the employer&apos;s website in a new tab.
          </span>
        </div>
      )}

      {shouldShowOpportunityApplyActions(sendCvOnly) && applyAction && !applyAction.usesWebsiteFallback && (
        <div className="mt-3 flex flex-col gap-2" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => handleApplyClick()}
              disabled={applied}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60"
            >
              <><ExternalLink className="w-3.5 h-3.5" /> {applied ? "Applied" : applyAction.label}</>
            </button>
            {linkVerified ? (
              <span
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200"
                title={linkCheckedAt ? `Link checked ${new Date(linkCheckedAt).toLocaleString("en-GB")}` : undefined}
              >
                <BadgeCheck className="w-3 h-3" /> Link verified
              </span>
            ) : linkCheckedAt ? (
              <span
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200"
                title="This link was checked but could not be fully verified — it may no longer be active"
              >
                <AlertCircle className="w-3 h-3" /> May not be active
              </span>
            ) : (
              <span
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200"
                title="This apply link has not been health-checked yet — it will be verified shortly"
              >
                <Clock className="w-3 h-3" /> Link not yet verified
              </span>
            )}
          </div>
          {deadLink && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
              <p className="font-semibold mb-1">This listing appears to no longer be available.</p>
              {hasContactDetails ? (
                <p className="text-red-700 mb-1">Try contacting the employer directly:</p>
              ) : contactWebsite ? (
                <p className="text-red-700 mb-1">The employer&apos;s website may have more information.</p>
              ) : null}
              <div className="flex flex-col gap-0.5">
                {contactEmail && (
                  <a href={`mailto:${contactEmail}`} className="text-red-700 hover:underline">
                    {contactEmail}
                  </a>
                )}
                {role.sourceType === "company_site" && contactWebsite && (
                  <button
                    type="button"
                    onClick={() => void handleApplyClick(
                      contactWebsite.startsWith("http") ? contactWebsite : `https://${contactWebsite}`
                    )}
                    className="text-left text-red-700 hover:underline"
                  >
                    Visit company website →
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      <div
        className="mt-4 flex items-center justify-between"
        onClick={(e) => e.stopPropagation()}
      >
        <span className="text-xs text-muted-foreground">
          Required: <span className="font-medium text-foreground">{role.requiredRegistration}</span>
        </span>
        <div className="flex gap-2">
          {onViewAnalysis && (
            <Button
              size="sm"
              variant="ghost"
              className="text-xs h-8 gap-1 text-primary/80 hover:text-primary hover:bg-primary/5"
              onClick={(e) => { e.stopPropagation(); onViewAnalysis(item); }}
            >
              <Sparkles className="w-3 h-3" /> Readiness Check
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            className="text-xs h-8 gap-1 text-muted-foreground"
            onClick={(e) => { e.stopPropagation(); onCoverLetter(role); }}
          >
            <FileText className="w-3 h-3" /> Cover Letter
          </Button>
          {canSendCvForVacancy(item) && (
            <Button
              size="sm"
              variant={cvSent ? "outline" : "accent"}
              className="text-xs h-8 gap-1"
              onClick={(e) => { e.stopPropagation(); onSendCv(item); }}
            >
              <Send className="w-3 h-3" /> {cvSent ? "Send CV again" : "Send CV"}
            </Button>
          )}
          {isEligible && !applied && (
            <Button
              size="sm"
              variant="default"
              className="text-xs h-8 gap-1"
              onClick={(e) => { e.stopPropagation(); onSmartApply(role.id, role.title); }}
            >
              <Sparkles className="w-3 h-3" /> Smart Apply
            </Button>
          )}
          {isEligible && applied && (
            <Button size="sm" variant="outline" className="text-xs h-8" disabled>
              Applied
            </Button>
          )}
          {!isEligible && !applied && (
            <Button
              size="sm"
              variant="outline"
              className="text-xs h-8 gap-1"
              onClick={(e) => { e.stopPropagation(); onSmartApply(role.id, role.title); }}
            >
              <Sparkles className="w-3 h-3" /> Apply
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}

type AppKind = "formal" | "speculative" | "website";
type AppSubTab = "platform" | "website" | "speculative";

type RichApplication = {
  id: number;
  userId: string;
  roleId: number;
  status: string;
  appliedAt: string;
  notes?: string | null;
  roleTitle?: string | null;
  roleLocation?: string | null;
  interviewDate?: string | Date | null;
  interviewNotes?: string | null;
  applicationKind?: AppKind;
  companyName?: string | null;
  vacancyTitle?: string | null;
  emailSent?: boolean | null;
  emailSentAt?: string | null;
  emailRecipient?: string | null;
  jobsageEmail?: string | null;
  applicationUrl?: string | null;
};

type RichStats = {
  total?: number;
  interviews?: number;
  offers?: number;
  noResponse?: number;
  platformCount?: number;
  websiteCount?: number;
  speculativeCount?: number;
  cvSent?: number;
};

const APP_STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  applied: { label: "Applied", className: "bg-blue-100 text-blue-800" },
  shortlisted: { label: "Shortlisted", className: "bg-purple-100 text-purple-800" },
  under_review: { label: "Under Review", className: "bg-violet-100 text-violet-800" },
  interview: { label: "Interview", className: "bg-teal-100 text-teal-800" },
  interview_invited: { label: "Interview Invited", className: "bg-teal-100 text-teal-800" },
  offer: { label: "Offer", className: "bg-emerald-100 text-emerald-800" },
  rejected: { label: "Rejected", className: "bg-red-100 text-red-700" },
  no_response: { label: "No Response", className: "bg-muted text-muted-foreground" },
  cv_sent: { label: "Send CV sent", className: "bg-sky-100 text-sky-800" },
  sent: { label: "Sent", className: "bg-sky-100 text-sky-800" },
  acknowledged: { label: "Acknowledged", className: "bg-emerald-100 text-emerald-800" },
};

function AppCard({ app }: { app: RichApplication }) {
  const kind = app.applicationKind ?? "formal";
  const isSpeculative = kind === "speculative";
  const isWebsite = kind === "website";
  const config = APP_STATUS_CONFIG[app.status] ?? APP_STATUS_CONFIG.applied!;

  const title = isSpeculative
    ? (app.vacancyTitle ?? app.companyName ?? "Send CV")
    : isWebsite
    ? (app.companyName ?? "Website Application")
    : (app.roleTitle ?? app.companyName ?? "Application");

  const dateLabel = isSpeculative ? "Sent" : "Applied";
  const dateStr = new Date(app.appliedAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });

  const hasInterview = app.interviewDate != null;
  const interviewStr = hasInterview
    ? new Date(app.interviewDate as string).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
    : null;

  return (
    <Card className={`p-4 space-y-2 ${hasInterview ? "border-teal-200" : ""}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm font-medium text-foreground truncate">{title}</p>
            {isWebsite && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold border bg-blue-50 text-blue-700 border-blue-200">
                <ExternalLink className="w-2.5 h-2.5" /> External Application
              </span>
            )}
            {isSpeculative && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold border bg-sky-50 text-sky-700 border-sky-200">
                <Send className="w-2.5 h-2.5" /> Send CV
              </span>
            )}
          </div>
          {app.companyName && (
            <p className="text-xs text-muted-foreground mt-0.5">{app.companyName}</p>
          )}
          <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {dateLabel} {dateStr}
          </p>
        </div>
        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold shrink-0 ${config.className}`}>
          {config.label}
        </span>
      </div>

      {isSpeculative && (
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          {app.emailSent ? (
            <span className="flex items-center gap-1 text-teal-700">
              <Send className="w-3 h-3" />
              Sent{app.emailRecipient ? ` to ${app.emailRecipient}` : app.jobsageEmail ? ` via ${app.jobsageEmail}` : " via JOBSAGE ops"}
            </span>
          ) : (
            <span className="flex items-center gap-1 text-muted-foreground">
              <Send className="w-3 h-3" /> Pending delivery
            </span>
          )}
        </div>
      )}

      {hasInterview && (
        <div className="flex flex-col gap-1 bg-teal-50 border border-teal-200 rounded-lg px-3 py-2 text-xs text-teal-800">
          <span className="flex items-center gap-1 font-semibold">
            <CalendarDays className="w-3 h-3" /> Interview: {interviewStr}
          </span>
          {app.interviewNotes && (
            <span className="text-teal-700 leading-relaxed">{app.interviewNotes}</span>
          )}
        </div>
      )}
    </Card>
  );
}

function ApplicationsTab({ data }: { data: ApplicationList | undefined }) {
  const [subTab, setSubTab] = useState<AppSubTab>("platform");

  if (!data) {
    return (
      <Card className="p-8 text-center">
        <ClipboardList className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
        <p className="text-sm text-muted-foreground">No applications tracked yet.</p>
        <p className="text-xs text-muted-foreground mt-1">Use Smart Apply or send your CV for a vacancy to track applications here.</p>
      </Card>
    );
  }

  const applications = (data.applications ?? []) as RichApplication[];
  const stats = data.stats as RichStats;

  const platformApps = applications.filter((a) => (a.applicationKind ?? "formal") === "formal");
  const websiteApps = applications.filter((a) => a.applicationKind === "website");
  const speculativeApps = applications.filter((a) => a.applicationKind === "speculative");

  const subTabs: { id: AppSubTab; label: string; icon: React.ElementType; count: number }[] = [
    { id: "platform", label: "Platform Applications", icon: Building2, count: stats.platformCount ?? platformApps.length },
    { id: "website", label: "Website Applications", icon: Globe, count: stats.websiteCount ?? websiteApps.length },
    { id: "speculative", label: "Send CV", icon: Send, count: stats.speculativeCount ?? speculativeApps.length },
  ];

  const visibleApps = subTab === "platform" ? platformApps : subTab === "website" ? websiteApps : speculativeApps;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Platform", value: stats.platformCount ?? platformApps.length, color: "text-foreground" },
          { label: "Website", value: stats.websiteCount ?? websiteApps.length, color: "text-blue-700" },
          { label: "Send CV", value: stats.speculativeCount ?? speculativeApps.length, color: "text-sky-700" },
          { label: "Interviews", value: stats.interviews ?? 0, color: "text-teal-700" },
        ].map(({ label, value, color }) => (
          <Card key={label} className="p-3 text-center">
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          </Card>
        ))}
      </div>

      <div className="flex gap-1 p-1 bg-muted rounded-xl overflow-x-auto">
        {subTabs.map(({ id, label, icon: Icon, count }) => (
          <button
            key={id}
            onClick={() => setSubTab(id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
              subTab === id ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            {label}
            {count > 0 && (
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${subTab === id ? "bg-primary/10 text-primary" : "bg-muted-foreground/10 text-muted-foreground"}`}>
                {count}
              </span>
            )}
          </button>
        ))}
      </div>

      {visibleApps.length === 0 ? (
        <Card className="p-8 text-center">
          <ClipboardList className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">
            {subTab === "platform" ? "No platform applications yet." : subTab === "website" ? "No website applications logged yet." : "No Send CV records yet."}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {subTab === "platform" ? "Use \"Smart Apply\" on a role to track it here." : subTab === "website" ? "Log an application made on an employer's website from the Applications page." : "Send your CV for a matched vacancy to track the outreach here."}
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {visibleApps.map((app) => (
            <AppCard key={`${app.applicationKind ?? "formal"}-${app.id}`} app={app} />
          ))}
        </div>
      )}
    </div>
  );
}

function SendCvEmployerGroup({
  employer,
  vacancies,
  cvSentRoleIds,
  hasCv,
  onSend,
  onUploadCv,
}: {
  employer: string;
  vacancies: MatchedRole[];
  cvSentRoleIds: number[];
  hasCv: boolean;
  onSend: (vacancy: MatchedRole) => void;
  onUploadCv: () => void;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center gap-3 border-b border-border bg-muted/30 px-5 py-4">
        <div className="w-10 h-10 rounded-xl bg-sky-500/10 flex items-center justify-center shrink-0">
          <Building2 className="w-5 h-5 text-sky-700" />
        </div>
        <div className="min-w-0">
          <h3 className="font-semibold text-foreground leading-snug">{employer}</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {vacancies.length} matched {vacancies.length === 1 ? "vacancy" : "vacancies"} with an available application route
          </p>
        </div>
      </div>

      <div className="divide-y divide-border">
        {vacancies.map((item) => {
          const { role } = item;
          const cvSent = cvSentRoleIds.includes(role.id);
          const canEmailCv = canSendCvForVacancy(item);
          const sourceLabel = !item.applyUrl
            ? "Email only"
            : role.sourceType === "job_board"
              ? role.boardName?.trim() || "Job board"
              : role.sourceType === "company_site"
                ? "Company site"
                : "Vacancy link";
          const regions = Array.isArray(role.targetRegions)
            ? role.targetRegions.filter((region) => region && region !== role.location)
            : [];

          return (
            <div key={role.id} className="px-5 py-4">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <h4 className="text-sm font-semibold text-foreground leading-snug">{role.title}</h4>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs text-muted-foreground">
                    {role.location && (
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {role.location}
                      </span>
                    )}
                    {regions.length > 0 && <span>{regions.join(", ")}</span>}
                    <span className="inline-flex items-center gap-1">
                      {item.applyUrl ? <ExternalLink className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
                      {sourceLabel}
                    </span>
                  </div>
                </div>
                {item.aiScore != null && <AiScoreBadge score={item.aiScore} />}
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {canEmailCv && hasCv ? (
                  <Button
                    size="sm"
                    variant={cvSent ? "outline" : "default"}
                    onClick={() => onSend(item)}
                  >
                    <Send className="w-4 h-4 mr-1.5" /> {cvSent ? "Send CV again" : "Send CV"}
                  </Button>
                ) : canEmailCv ? (
                  <Button size="sm" variant="outline" onClick={onUploadCv}>
                    <FileText className="w-4 h-4 mr-1.5" /> Upload CV to send
                  </Button>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function SelfPromotionCard() {
  const [budget, setBudget] = useState("");
  return (
    <Card className="p-5 border-dashed border-2 border-primary/20 bg-gradient-to-br from-primary/3 to-accent/3">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Megaphone className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-sm font-semibold text-foreground">Boost Your Profile</h3>
            <span className="px-1.5 py-0.5 text-xs rounded bg-primary/10 text-primary font-medium">Coming Soon</span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed mb-3">
            Premium candidates can promote their profile to NHS trusts and academic institutions actively recruiting in their specialty.
          </p>
          <div className="flex items-center gap-2">
            <div className="relative flex-1 max-w-[160px]">
              <DollarSign className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="number"
                min="0"
                step="10"
                placeholder="Monthly budget"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                disabled
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-border bg-background/50 text-muted-foreground cursor-not-allowed"
              />
            </div>
            <Button size="sm" className="text-xs" disabled>
              Set Budget &amp; Go Live
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}

export default function OpportunitiesPage() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>(() => {
    const p = new URLSearchParams(window.location.search);
    const t = p.get("tab");
    return (t === "employers" || t === "board" || t === "sendcv") ? t as Tab : "board";
  });
  const [selectedRole, setSelectedRole] = useState<MatchedRole | null>(null);
  const [sendCvSearch, setSendCvSearch] = useState("");
  const [sendCvTarget, setSendCvTarget] = useState<MatchedRole | null>(null);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [smartApplyRole, setSmartApplyRole] = useState<{ id: number; title: string } | null>(null);
  const [coverLetterRole, setCoverLetterRole] = useState<MatchedRole["role"] | null>(null);
  const [gapAnalysisRole, setGapAnalysisRole] = useState<MatchedRole | null>(null);
  const [showExtensionNudge, setShowExtensionNudge] = useState(false);
  // Applying requires the Smart Apply extension so outbound applications are tracked.
  const { requireExtension, gateModal } = useExtensionGate();

  function handleExternalApply() {
    if (shouldShowExtensionNudge()) setShowExtensionNudge(true);
  }

  function handleBestMatchOpenApplication(url: string, match: CandidateMatchItem, vacancyIntent: boolean) {
    requireExtension(() => {
      void openTrackedOutbound({
        url,
        vacancy: vacancyIntent ? {
          title: match.title,
          employer: match.employer,
          roleId: match.roleId,
          canonicalUrl: url,
        } : undefined,
      });
      handleExternalApply();
    });
  }

  const queryClient = useQueryClient();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const opportunitySource = activeTab === "employers" ? "company_site" : activeTab === "board" ? "job_board" : undefined;
  const isVacancyTab = activeTab === "board" || activeTab === "employers" || activeTab === "sendcv";
  const isCompanySiteTab = activeTab === "employers";
  const resultsSectionId = isCompanySiteTab ? "company-site-section" : "job-board-section";
  const {
    data,
    isLoading,
    isError,
    isFetching,
    refetch: refetchRoles,
  } = useQuery({
    queryKey: getListMatchedRolesQueryKey({ source: opportunitySource }),
    enabled: isVacancyTab,
    queryFn: ({ signal }) => listMatchedRolesWithTimeout(opportunitySource, signal),
    retry: 1,
    placeholderData: (previousData) => previousData,
  });
  const { data: applicationsData } = useListMyApplications();
  const { data: documentsData } = useListMyDocuments();
  const { data: myProfile } = useGetMyProfile();
  const profileMutation = useUpsertMyProfile();
  const { toast } = useToast();
  const [regionSaveState, setRegionSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const regionSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [localDismissedIds, setLocalDismissedIds] = useState<Set<number>>(new Set());
  const { data: aiMatchesData, isLoading: aiMatchesLoading } = useGetMyMatches(
    { limit: 200, source: opportunitySource },
    { query: { queryKey: getGetMyMatchesQueryKey({ limit: 200, source: opportunitySource }), enabled: isAuthenticated && !authLoading && isVacancyTab, retry: false } },
  );
  const dismissMutation = useDismissMatch();

  // /roles/my-matches may finish and persist fresh AI scores after the main
  // /roles request has already returned. Refetch the cards once scoring settles
  // so both sections display the same score snapshot.
  useEffect(() => {
    if (!aiMatchesData) return;
    void queryClient.invalidateQueries({
      queryKey: getListMatchedRolesQueryKey({ source: opportunitySource }),
    });
  }, [aiMatchesData, opportunitySource, queryClient]);

  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const { data: vacancyStatsData } = useQuery<{ companiesChecked: number; companiesWithVacancies: number; totalVacanciesFound: number }>({
    queryKey: ["sponsorVacancyStats"],
    queryFn: async () => {
      const res = await fetch(`${base}/api/sponsor-licences/vacancy-stats`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch vacancy stats");
      return res.json() as Promise<{ companiesChecked: number; companiesWithVacancies: number; totalVacanciesFound: number }>;
    },
    staleTime: 5 * 60 * 1000,
  });

  function handleDismissMatch(roleId: number) {
    setLocalDismissedIds((prev) => new Set([...prev, roleId]));
    dismissMutation.mutate(
      { data: { roleId } },
      {
        onSettled: () => {
          void queryClient.invalidateQueries({ queryKey: getGetMyMatchesQueryKey({ limit: 200, source: opportunitySource }) });
        },
      },
    );
  }

  const roles = data?.roles ?? [];
  const appliedRoleIds = data?.appliedRoleIds ?? [];
  const cvSentRoleIds = data?.cvSentRoleIds ?? [];
  const eligibilityOutcome = data?.eligibilityOutcome;
  const noProfile = data?.noProfile === true;
  useEffect(() => {
    const profileRegions = myProfile?.preferredRegion;
    setSelectedRegions(
      Array.isArray(profileRegions)
        ? profileRegions.filter((region): region is string => typeof region === "string" && (UK_REGIONS as readonly string[]).includes(region))
        : [],
    );
    setRegionSaveState("idle");
  }, [myProfile?.userId, myProfile?.preferredRegion]);

  useEffect(() => () => {
    if (regionSaveTimerRef.current) clearTimeout(regionSaveTimerRef.current);
  }, []);

  const saveRegionsToProfile = (nextRegions: string[]) => {
    setSelectedRegions(nextRegions);
    if (!myProfile) return;

    if (regionSaveTimerRef.current) clearTimeout(regionSaveTimerRef.current);
    setRegionSaveState("saving");
    regionSaveTimerRef.current = setTimeout(() => {
      regionSaveTimerRef.current = null;
      profileMutation.mutate(
        {
          data: {
            profession: myProfile.profession ?? "",
            specialty: myProfile.specialty ?? "",
            qualificationCountry: myProfile.qualificationCountry ?? "",
            qualificationType: myProfile.qualificationType ?? "",
            qualificationYear: myProfile.qualificationYear ?? 0,
            experienceYears: myProfile.experienceYears ?? 0,
            registrationStatus: myProfile.registrationStatus ?? "not_registered",
            licenceReady: myProfile.licenceReady ?? null,
            dbsClearanceLevel: myProfile.dbsClearanceLevel ?? undefined,
            safeguardingTrainingLevel: myProfile.safeguardingTrainingLevel ?? undefined,
            residencyStatus: myProfile.residencyStatus ?? "",
            requiresSponsorship: myProfile.requiresSponsorship ?? false,
            preferredRegion: nextRegions,
            alertFrequency: myProfile.alertFrequency === "off" ? "off" : "weekly",
            preferredStartDate: myProfile.preferredStartDate ?? null,
            profilePhotoKey: myProfile.profilePhotoKey ?? null,
            languages: myProfile.languages ?? null,
            additionalNotes: myProfile.additionalNotes ?? null,
            phone: myProfile.phone ?? null,
            streetAddress: myProfile.streetAddress ?? null,
            city: myProfile.city ?? null,
            postcode: myProfile.postcode ?? null,
            country: myProfile.country ?? null,
          },
        },
        {
          onSuccess: () => {
            setRegionSaveState("saved");
            void queryClient.invalidateQueries({ queryKey: getGetMyProfileQueryKey() });
          },
          onError: () => {
            setRegionSaveState("error");
            toast({
              title: "Could not save region preference",
              description: "Your selection is still active for this view. Please try again.",
              variant: "destructive",
            });
          },
        },
      );
    }, 300);
  };

  const filters = { selectedRegions };
  const filteredRoles = roles.filter((item) => filterOpportunities([item.role], filters).length > 0);
  const filteredAiMatchesData = aiMatchesData
    ? { ...aiMatchesData, matches: filterOpportunities(aiMatchesData.matches, filters) }
    : aiMatchesData;

  // The server now embeds AI scores and sorts by the same unified key the UI
  // previously computed client-side (AI score when cached, heuristic otherwise).
  // Use the server's order directly — no client-side re-sort needed.
  const {
    recommended: recommendedRoles,
    consider: next5Roles,
    remaining: remainingRoles,
  } = groupRankedOpportunities(filteredRoles);

  const normalizedSendCvSearch = sendCvSearch.trim().toLowerCase();
  const sendCvVacancies = filteredRoles.filter((item) => {
    if (!shouldShowOnSendCvTab(item)) return false;
    if (!normalizedSendCvSearch) return true;
    return [item.role.employer, item.role.title, item.role.location]
      .some((value) => value?.toLowerCase().includes(normalizedSendCvSearch));
  });
  const sendCvGroups = Array.from(
    sendCvVacancies.reduce((groups, vacancy) => {
      const key = vacancy.role.employer.trim().toLowerCase();
      const existing = groups.get(key);
      if (existing) {
        existing.vacancies.push(vacancy);
      } else {
        groups.set(key, { employer: vacancy.role.employer, vacancies: [vacancy] });
      }
      return groups;
    }, new Map<string, { employer: string; vacancies: MatchedRole[] }>()),
  ).map(([, group]) => group);
  const hasCvUploaded = (documentsData?.documents ?? []).some((document) => document.documentType === "cv");

  function handleSmartApply(roleId: number, roleTitle: string) {
    // The server owns Smart Apply readiness and returns the exact missing
    // application-critical fields. A duplicate client gate previously blocked
    // valid profiles on optional preferences and stale profile-query state.
    requireExtension(() => setSmartApplyRole({ id: roleId, title: roleTitle }));
  }

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "board", label: "Apply Via Job Board", icon: Briefcase },
    { id: "employers", label: "Apply on company websites", icon: Building2 },
    { id: "sendcv", label: "Send CV", icon: Send },
  ];

  return (
    <AppLayout>
      <PageTransition className="max-w-4xl mx-auto p-6 space-y-6">
        <DisclaimerBanner />

        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-display font-bold text-foreground">Job Opportunities</h1>
            <p className="text-muted-foreground mt-1 text-sm">
              {activeTab === "sendcv"
                ? "Licensed sponsors ranked by the strongest available match evidence. Send CV is saved as pending when no stored employer contact is available."
                : noProfile
                ? "Complete your profile to see a personalised ranked list."
                : data
                ? `${filteredRoles.length} of ${roles.length} ${isCompanySiteTab ? "company-site vacancies" : "job-board vacancies"} ranked by fit — highest match first`
                : "All vacancies ranked by how well they match your profile."}
            </p>
            {(vacancyStatsData?.totalVacanciesFound ?? 0) > 0 && (
              <p className="text-xs text-muted-foreground mt-0.5">
                Historical discovery records: {vacancyStatsData!.totalVacanciesFound} vacancies across {vacancyStatsData!.companiesWithVacancies} employer{vacancyStatsData!.companiesWithVacancies !== 1 ? "s" : ""}. Only verified live vacancies appear below.
                {" · "}
                <a href="/sponsor-licences" className="underline underline-offset-2 hover:text-primary transition-colors">View sponsors</a>
              </p>
            )}
          </div>
          {eligibilityOutcome && (
            <div className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 ${
              eligibilityOutcome === "eligible"
                ? "bg-emerald-100 text-emerald-800"
                : "bg-amber-100 text-amber-800"
            }`}>
              {eligibilityOutcome === "eligible" ? (
                <><BadgeCheck className="w-3.5 h-3.5" /> Eligible</>
              ) : (
                <><Clock className="w-3.5 h-3.5" /> Building eligibility</>
              )}
            </div>
          )}
        </div>

        {/* Tab navigation */}
        <div className="flex gap-1 p-1 bg-muted rounded-xl">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === id
                  ? "bg-background shadow-sm text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </div>

        {/* Loading / error states */}
        {isLoading && !data && isVacancyTab && (
          <Card className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground text-sm">Loading opportunities…</p>
          </Card>
        )}

        {isError && isVacancyTab && (
          <Card className="p-8 text-center border-destructive/20">
            <AlertCircle className="w-10 h-10 text-destructive mx-auto mb-3" />
            <p className="text-sm text-destructive font-medium">Could not load opportunities.</p>
            <p className="text-xs text-muted-foreground mt-1">
              {data
                ? "The last loaded list is still shown below. Retry when your connection is stable."
                : "The server did not respond in time. Please retry."}
            </p>
            <Button size="sm" className="mt-4" onClick={() => void refetchRoles()} disabled={isFetching}>
              {isFetching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Retry
            </Button>
          </Card>
        )}

        {/* Ranked vacancy tabs */}
        {(!isLoading || !!data) && isVacancyTab && activeTab !== "sendcv" && (
          <div className="space-y-8">
            {/* No-profile nudge */}
            {noProfile && (
              <Card className="p-8 text-center border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
                <FileText className="w-10 h-10 text-primary/40 mx-auto mb-3" />
                <h2 className="text-lg font-semibold mb-2">Complete your profile to unlock ranked vacancies</h2>
                <p className="text-sm text-muted-foreground mb-5 max-w-md mx-auto">
                  Upload your CV and fill in your profile so we can rank every vacancy by how well it matches your qualifications, registration status, and sponsorship needs.
                </p>
                <div className="flex gap-3 justify-center flex-wrap">
                  <Button onClick={() => setLocation("/profile")}>
                    Complete Profile <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                  <Button variant="outline" onClick={() => setLocation("/documents")}>
                    <FileText className="w-4 h-4 mr-2" /> Upload CV
                  </Button>
                </div>
              </Card>
            )}

            {/* Region filters stay above ranked results so candidates can set the
                location scope before reviewing their matches. */}
            {!noProfile && roles.length > 0 && (
              <Card className="p-4 border-primary/15 bg-primary/[0.02]">
                  <div className="flex flex-col gap-4">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <h2 className="text-sm font-semibold text-foreground">Refine opportunities</h2>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Region filters keep roles with an unknown or national location visible.
                      </p>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">UK region</p>
                    <div className="flex flex-wrap gap-2">
                      {UK_REGIONS.map((region) => {
                        const selected = selectedRegions.includes(region);
                        return (
                          <button
                            key={region}
                            type="button"
                            aria-pressed={selected}
                            onClick={() => saveRegionsToProfile(
                              selected
                                ? selectedRegions.filter((value) => value !== region)
                                : [...selectedRegions, region],
                            )}
                            className={`rounded-full px-3 py-1.5 text-xs font-medium border transition-colors ${
                              selected
                                ? "border-primary bg-primary text-primary-foreground"
                                : "border-border bg-background text-muted-foreground hover:text-foreground hover:border-primary/40"
                            }`}
                          >
                            {region}
                          </button>
                        );
                      })}
                      {selectedRegions.length > 0 && (
                        <button
                          type="button"
                          onClick={() => saveRegionsToProfile([])}
                          className="rounded-full px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/10"
                        >
                          Clear regions
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      {regionSaveState === "saving"
                        ? "Saving to your Professional Profile…"
                        : regionSaveState === "error"
                          ? "Could not save your profile preference."
                          : regionSaveState === "saved"
                            ? "Saved to your Professional Profile."
                            : "This selection is linked to your Professional Profile."}
                    </p>
                  </div>
                </div>
              </Card>
            )}

            {/* Best Matches AI Strip */}
            {!noProfile && filteredRoles.length > 0 && (
              <BestMatchesStrip
                matchesData={filteredAiMatchesData}
                matchesLoading={aiMatchesLoading}
                appliedRoleIds={appliedRoleIds}
                localDismissedIds={localDismissedIds}
                onSmartApply={handleSmartApply}
                onOpenApplication={handleBestMatchOpenApplication}
                onDismiss={handleDismissMatch}
                sourceType={opportunitySource ?? "job_board"}
              />
            )}

            {/* Smart Apply extension banner */}
            {!noProfile && filteredRoles.length > 0 && <SmartApplyExtensionBanner />}

            {!noProfile && roles.length === 0 && (
              <Card className="p-8 text-center">
                <Briefcase className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
                <h2 className="text-lg font-semibold mb-2">No roles in catalogue yet</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  {isCompanySiteTab
                    ? "No verified company-site vacancies currently match your profession."
                    : "No roles have been imported for your profession yet. Check back soon."}
                </p>
                <Button variant="outline" onClick={() => setLocation("/eligibility")}>
                  Run Eligibility Check <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Card>
            )}

            {!noProfile && roles.length > 0 && (
              <>
                {filteredRoles.length === 0 && (
                  <Card className="p-7 text-center">
                    <Briefcase className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
                    <h2 className="text-base font-semibold">No opportunities match these filters</h2>
                    <p className="text-sm text-muted-foreground mt-1">Try another region to broaden your results.</p>
                  </Card>
                )}
                {/* Match score info note */}
                {filteredRoles.length > 0 && <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 shrink-0 text-primary/60" />
                  Match scores are based on your CV, profile, and regulatory eligibility. Vacancies outside your professional category are excluded.
                </p>}

                {/* Recommended — Apply First band */}
                {recommendedRoles.length > 0 && (
                  <section>
                    <div className="flex items-center gap-2 mb-3">
                      <Medal className="w-4 h-4 text-primary" />
                      <h2 className="text-base font-semibold text-foreground">Recommended — Apply First</h2>
                      <span className="px-1.5 py-0.5 text-xs rounded bg-primary/10 text-primary font-medium">
                        Top {recommendedRoles.length}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mb-4">
                      Your highest-matching vacancies right now — these best fit your profile and eligibility status.
                    </p>
                    <div className="space-y-3">
                      {recommendedRoles.map((item) => (
                        <motion.div
                          key={`rec-${item.role.id}`}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                        >
                          <RoleCard
                            item={item}
                            recommended
                            aiScore={item.aiScore ?? undefined}
                            aiScoring={aiMatchesLoading}
                            appliedRoleIds={appliedRoleIds}
                            cvSentRoleIds={cvSentRoleIds}
                            onSendCv={setSendCvTarget}
                            onSmartApply={handleSmartApply}
                            onViewDetail={setSelectedRole}
                            onCoverLetter={setCoverLetterRole}
                            onViewAnalysis={setGapAnalysisRole}
                            requireExtension={requireExtension}
                            onExternalApply={handleExternalApply}
                            sendCvOnly={false}
                          />
                        </motion.div>
                      ))}
                    </div>
                  </section>
                )}

                {/* Remaining ranked lists */}
                <div id={resultsSectionId} className="space-y-8">
                  {/* Roles that clear the consideration threshold */}
                  {next5Roles.length > 0 && (
                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <TrendingUp className="w-4 h-4 text-blue-500" />
                        <h2 className="text-base font-semibold text-foreground">Worth Considering</h2>
                        <span className="px-1.5 py-0.5 text-xs rounded bg-blue-100 text-blue-700 font-medium">
                          Relevant Options
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-4">
                        Relevant options that meet the minimum professional-fit threshold.
                      </p>
                      <div className="space-y-3">
                        {next5Roles.map((item) => (
                          <motion.div
                            key={item.role.id}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                          >
                            <RoleCard
                              item={item}
                              recommended={false}
                              aiScore={item.aiScore ?? undefined}
                              aiScoring={aiMatchesLoading}
                              appliedRoleIds={appliedRoleIds}
                              cvSentRoleIds={cvSentRoleIds}
                              onSendCv={setSendCvTarget}
                              onSmartApply={handleSmartApply}
                              onViewDetail={setSelectedRole}
                              onCoverLetter={setCoverLetterRole}
                              onViewAnalysis={setGapAnalysisRole}
                              requireExtension={requireExtension}
                              onExternalApply={handleExternalApply}
                              sendCvOnly={false}
                            />
                          </motion.div>
                        ))}
                      </div>
                    </section>
                  )}

                  {/* Lower-confidence catalogue */}
                  {remainingRoles.length > 0 && (
                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <Briefcase className="w-4 h-4 text-muted-foreground" />
                        <h2 className="text-base font-semibold text-foreground">More Opportunities</h2>
                        <span className="px-1.5 py-0.5 text-xs rounded bg-muted text-muted-foreground font-medium">
                          {remainingRoles.length} more
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-4">
                        All remaining vacancies — broaden your search or revisit after your top applications.
                      </p>
                      <div className="space-y-3">
                        {remainingRoles.map((item) => (
                          <motion.div
                            key={item.role.id}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                          >
                            <RoleCard
                              item={item}
                              recommended={false}
                              aiScore={item.aiScore ?? undefined}
                              aiScoring={aiMatchesLoading}
                              appliedRoleIds={appliedRoleIds}
                              cvSentRoleIds={cvSentRoleIds}
                              onSendCv={setSendCvTarget}
                              onSmartApply={handleSmartApply}
                              onViewDetail={setSelectedRole}
                              onCoverLetter={setCoverLetterRole}
                              onViewAnalysis={setGapAnalysisRole}
                              requireExtension={requireExtension}
                              onExternalApply={handleExternalApply}
                              sendCvOnly={false}
                            />
                          </motion.div>
                        ))}
                      </div>
                    </section>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* Send CV tab */}
        {activeTab === "sendcv" && (
          <div className="space-y-4">
            <Card className="p-5 border-sky-500/20 bg-sky-500/[0.04]">
              <div className="flex items-start gap-3">
                <Send className="w-5 h-5 text-sky-700 mt-0.5" />
                <div>
                  <h2 className="text-sm font-semibold">Contact licensed sponsors directly</h2>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                    Matched vacancies are grouped by employer. Send your CV when a direct employer email is available, or use the verified application route.
                  </p>
                </div>
              </div>
            </Card>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="search"
                value={sendCvSearch}
                onChange={(event) => setSendCvSearch(event.target.value)}
                placeholder="Search employers or vacancy titles…"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
            {isLoading ? (
              <Card className="p-8 text-center">
                <Loader2 className="w-8 h-8 text-primary animate-spin mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">Loading matched vacancies with available application routes…</p>
              </Card>
            ) : isError ? (
              <Card className="p-8 text-center border-destructive/20">
                <AlertCircle className="w-9 h-9 text-destructive mx-auto mb-3" />
                <p className="text-sm font-medium text-destructive">Could not load matched vacancies.</p>
              </Card>
            ) : sendCvGroups.length === 0 ? (
              <Card className="p-8 text-center">
                <Briefcase className="w-9 h-9 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm font-medium text-foreground">No matched vacancies with a usable application route.</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try changing your search or region filters. Vacancies appear here when JOBSAGE has a verified apply link or a usable employer email.
                </p>
              </Card>
            ) : (
              <>
                <p className="text-xs text-muted-foreground">
                  {sendCvVacancies.length} matched {sendCvVacancies.length === 1 ? "vacancy" : "vacancies"} across {sendCvGroups.length} {sendCvGroups.length === 1 ? "employer" : "employers"}
                </p>
                <div className="space-y-3">
                  {sendCvGroups.map((group) => (
                    <SendCvEmployerGroup
                      key={group.employer.trim().toLowerCase()}
                      employer={group.employer}
                      vacancies={group.vacancies}
                      cvSentRoleIds={cvSentRoleIds}
                      hasCv={hasCvUploaded}
                      onSend={setSendCvTarget}
                      onUploadCv={() => setLocation("/documents")}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* Self-promotion placeholder */}
        {activeTab === "board" && !isLoading && !isError && (
          <SelfPromotionCard />
        )}
      </PageTransition>

      {/* Role detail modal */}
      <AnimatePresence>
        {sendCvTarget && (
          <SmartApplyModal
            roleId={sendCvTarget.role.id}
            roleTitle={sendCvTarget.role.title}
            sendCvContext={{
              title: sendCvTarget.role.title,
              companyName: sendCvTarget.role.employer,
              employer: sendCvTarget.role.employer,
              location: sendCvTarget.role.location,
              regulator: sendCvTarget.role.statutoryRegulator ?? sendCvTarget.role.regulator ?? sendCvTarget.role.opportunityCategory ?? null,
              externalUrl: sendCvTarget.applyUrl ?? null,
              sourceType: sendCvTarget.role.sourceType ?? null,
              boardName: sendCvTarget.role.boardName ?? null,
            }}
            onClose={() => setSendCvTarget(null)}
            onSuccess={() => {
              setSendCvTarget(null);
              void queryClient.invalidateQueries({ queryKey: ["listSpeculativeApplications"] });
              void queryClient.invalidateQueries({ queryKey: getListMyApplicationsQueryKey() });
              void queryClient.invalidateQueries({ queryKey: getListMatchedRolesQueryKey() });
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedRole && (
          <RoleDetailModal
            item={selectedRole}
            aiScore={selectedRole.aiScore ?? undefined}
            appliedRoleIds={appliedRoleIds}
            onClose={() => setSelectedRole(null)}
          />
        )}
      </AnimatePresence>

      {/* Smart Apply modal */}
      <AnimatePresence>
        {smartApplyRole && (
          <SmartApplyModal
            roleId={smartApplyRole.id}
            roleTitle={smartApplyRole.title}
            onClose={() => setSmartApplyRole(null)}
            onSuccess={() => {
              setSmartApplyRole(null);
              void queryClient.invalidateQueries({ queryKey: getListMyApplicationsQueryKey() });
              void queryClient.invalidateQueries({ queryKey: getListMatchedRolesQueryKey() });
            }}
          />
        )}
      </AnimatePresence>

      {/* Cover Letter modal */}
      <AnimatePresence>
        {coverLetterRole && (
          <CoverLetterModal
            role={coverLetterRole}
            onClose={() => setCoverLetterRole(null)}
          />
        )}
      </AnimatePresence>

      {/* Smart Apply extension nudge (after clicking through to an employer site) */}
      <SmartApplyExtensionNudge open={showExtensionNudge} onClose={() => setShowExtensionNudge(false)} />

      {/* AI Gap Analysis Sheet */}
      {gapAnalysisRole && (() => {
        // Sponsor vacancies are surfaced on the Opportunities page with
        // id = vacancyId + SPONSOR_VACANCY_ID_OFFSET (2_000_000).
        // Route to the sponsor-licences endpoint for those; fall back to the
        // matched-roles endpoint for any real catalogue roles (future-proof).
        const SPONSOR_OFFSET = 2_000_000;
        const isSponsorVacancy = gapAnalysisRole.role.id >= SPONSOR_OFFSET;
        const vacancyId = isSponsorVacancy
          ? gapAnalysisRole.role.id - SPONSOR_OFFSET
          : gapAnalysisRole.role.id;
        const endpoint = isSponsorVacancy
          ? `/sponsor-licences/vacancies/${vacancyId}/gap-analysis`
          : `/opportunities/roles/${gapAnalysisRole.role.id}/gap-analysis`;
        return (
          <GapAnalysisSheet
            open={gapAnalysisRole != null}
            onOpenChange={(open) => { if (!open) setGapAnalysisRole(null); }}
            vacancyId={vacancyId}
            vacancyTitle={gapAnalysisRole.role.title}
            companyName={gapAnalysisRole.role.employer}
            vacancyUrl={gapAnalysisRole.applyUrl ?? gapAnalysisRole.contactWebsite ?? null}
            sourceType={gapAnalysisRole.role.sourceType}
            trackVacancyIntent={!!gapAnalysisRole.applyUrl}
            hasCvUploaded={!!myProfile}
            analysisEndpoint={endpoint}
            analysisSource={isSponsorVacancy ? "sponsor_vacancy" : "role"}
            onApply={() => handleSmartApply(gapAnalysisRole.role.id, gapAnalysisRole.role.title)}
          />
        );
      })()}

      {gateModal}

    </AppLayout>
  );
}
