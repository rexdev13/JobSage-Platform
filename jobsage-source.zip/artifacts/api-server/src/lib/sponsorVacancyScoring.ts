import { db } from "@workspace/db";
import { profilesTable, sponsorLicenceVacancyScoresTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { batchScoreVacancies, type CandidateProfileForScoring, type VacancyForScoring } from "./sponsorVacancyMatch";

interface UnscoredVacancyRow {
  [key: string]: unknown;
  id: number;
  organisation_name: string;
  title: string;
  location: string | null;
  description: string | null;
}

function toProfileForScoring(profile: typeof profilesTable.$inferSelect): CandidateProfileForScoring {
  return {
    profession: profile.profession,
    specialty: profile.specialty,
    experienceYears: profile.experienceYears,
    qualificationCountry: profile.qualificationCountry,
    registrationStatus: profile.registrationStatus,
    requiresSponsorship: profile.requiresSponsorship,
  };
}

/**
 * Incrementally score suitability for this candidate: only vacancies that do
 * not yet have a score row for this user are sent to the AI, and results are
 * upserted per vacancy. Called after every check-all pass and by the daily
 * sync — a handful of newly-discovered vacancies therefore costs one small AI
 * batch, never a full re-score of the whole catalogue.
 */
export async function rescoreVacanciesForUser(userId: string): Promise<{ scored: number }> {
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, userId)).limit(1);
  if (!profile) return { scored: 0 };

  const allVacancies = await db.execute<UnscoredVacancyRow>(sql`
    SELECT v.id, v.organisation_name, v.title, v.location, v.description
    FROM sponsor_licence_vacancies v
    WHERE NOT EXISTS (
      SELECT 1 FROM sponsor_licence_vacancy_scores s
      WHERE s.vacancy_id = v.id AND s.user_id = ${userId}
    )
  `);

  if (allVacancies.rows.length === 0) return { scored: 0 };

  const vacanciesForScoring: VacancyForScoring[] = allVacancies.rows.map((r) => ({
    id: r.id,
    title: r.title,
    organisationName: r.organisation_name,
    location: r.location,
    description: r.description,
  }));

  const profileForScoring = toProfileForScoring(profile);
  const scoreMap = await batchScoreVacancies(profileForScoring, vacanciesForScoring);

  await db
    .insert(sponsorLicenceVacancyScoresTable)
    .values(
      allVacancies.rows.map((r) => {
        const s = scoreMap.get(r.id);
        return {
          userId,
          vacancyId: r.id,
          organisationName: r.organisation_name,
          score: s?.score ?? 50,
          isEligible: s?.isEligible ?? false,
          missingRequirements: s?.missingRequirements ?? [],
          explanation: s?.explanation ?? "Match based on your profile and vacancy details.",
          scoredAt: new Date(),
        };
      }),
    )
    .onConflictDoUpdate({
      target: [sponsorLicenceVacancyScoresTable.userId, sponsorLicenceVacancyScoresTable.vacancyId],
      set: {
        organisationName: sql`excluded.organisation_name`,
        score: sql`excluded.score`,
        isEligible: sql`excluded.is_eligible`,
        missingRequirements: sql`excluded.missing_requirements`,
        explanation: sql`excluded.explanation`,
        scoredAt: sql`excluded.scored_at`,
      },
    });

  return { scored: allVacancies.rows.length };
}

/**
 * Score only this employer's vacancies for a single candidate, on demand.
 * Used when a candidate presses "Check Best Fit" on a company whose vacancies
 * have not been scored against their profile yet. Only unscored vacancies are
 * sent to the AI, so repeat calls are cheap no-ops.
 */
export async function scoreVacanciesForCompany(
  userId: string,
  organisationName: string,
): Promise<{ scored: number }> {
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, userId)).limit(1);
  if (!profile) return { scored: 0 };

  const unscored = await db.execute<UnscoredVacancyRow>(sql`
    SELECT v.id, v.organisation_name, v.title, v.location, v.description
    FROM sponsor_licence_vacancies v
    WHERE v.organisation_name = ${organisationName}
      AND v.liveness <> 'dead'
      AND NOT EXISTS (
        SELECT 1 FROM sponsor_licence_vacancy_scores s
        WHERE s.vacancy_id = v.id AND s.user_id = ${userId}
      )
  `);

  if (unscored.rows.length === 0) return { scored: 0 };

  const vacanciesForScoring: VacancyForScoring[] = unscored.rows.map((r) => ({
    id: r.id,
    title: r.title,
    organisationName: r.organisation_name,
    location: r.location,
    description: r.description,
  }));

  const scoreMap = await batchScoreVacancies(toProfileForScoring(profile), vacanciesForScoring);

  await db
    .insert(sponsorLicenceVacancyScoresTable)
    .values(
      unscored.rows.map((r) => {
        const s = scoreMap.get(r.id);
        return {
          userId,
          vacancyId: r.id,
          organisationName: r.organisation_name,
          score: s?.score ?? 50,
          isEligible: s?.isEligible ?? false,
          missingRequirements: s?.missingRequirements ?? [],
          explanation: s?.explanation ?? "Match based on your profile and vacancy details.",
          scoredAt: new Date(),
        };
      }),
    )
    .onConflictDoUpdate({
      target: [sponsorLicenceVacancyScoresTable.userId, sponsorLicenceVacancyScoresTable.vacancyId],
      set: {
        organisationName: sql`excluded.organisation_name`,
        score: sql`excluded.score`,
        isEligible: sql`excluded.is_eligible`,
        missingRequirements: sql`excluded.missing_requirements`,
        explanation: sql`excluded.explanation`,
        scoredAt: sql`excluded.scored_at`,
      },
    });

  return { scored: unscored.rows.length };
}

/**
 * Rescore vacancies for every candidate with a profile.
 * Used by the daily scheduled job after a full vacancy check pass.
 */
export async function rescoreVacanciesForAllUsers(): Promise<{ usersProcessed: number; totalScored: number }> {
  const users = await db.selectDistinct({ userId: profilesTable.userId }).from(profilesTable);

  let totalScored = 0;
  for (const u of users) {
    try {
      const { scored } = await rescoreVacanciesForUser(u.userId);
      totalScored += scored;
    } catch (err) {
      console.error(`[sponsor-vacancy-scoring] Failed to rescore for user ${u.userId}:`, err instanceof Error ? err.message : err);
    }
  }

  return { usersProcessed: users.length, totalScored };
}
