import { employerNamesCloselyMatch } from "./nhsJobsClient";
import { canonicalVacancyUrl } from "./vacancySource";
import { isValidJobBoardVacancyDeepLink } from "./vacancyUrlPolicy";
import { extractAdvertContactEmail } from "./publishedContactEmail";
import { extractVacancyClosingDate } from "./vacancyDates";

const REED_BASE_URL = "https://www.reed.co.uk";
const REQUEST_TIMEOUT_MS = 12_000;
const MAX_RESULTS = 8;
const POLITE_REQUEST_DELAY_MS = 350;
export const MAX_REED_CANDIDATE_PAGES = 15;

export interface ReedVacancy {
  title: string;
  employer: string;
  location: string | null;
  salary: string | null;
  url: string;
  description: null;
  postedDate: string | null;
  targetRegions: null;
  sourceType: "job_board";
  boardName: "Reed";
  externalListingId: string;
  contactEmail: string | null;
  contactEvidenceUrl: string | null;
  closesAt?: Date | null;
}

export interface ReedSearchResult {
  vacancies: ReedVacancy[];
  sourceUrl: string;
  requestSucceeded: boolean;
  transientFailure: boolean;
}

export interface ReedCandidateSearchResult extends ReedSearchResult {}

function decodeHtml(value: string): string {
  return value
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&#x27;|&#39;|&apos;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/&amp;/gi, "&")
    .replace(/&pound;/gi, "£")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tagByQa(card: string, qa: string): string | null {
  const match = card.match(
    new RegExp(`<([a-z0-9]+)\\b[^>]*data-qa=["']${qa}["'][^>]*>([\\s\\S]*?)<\\/\\1>`, "i"),
  );
  return match?.[0] ?? null;
}

function employerFromCard(card: string): string | null {
  const explicitEmployerTag = tagByQa(card, "company-name-link");
  if (explicitEmployerTag) return decodeHtml(explicitEmployerTag);

  // Reed's current cards place the employer in the recruiter link inside the
  // posted-by block; keep the old company-name-link path for older markup.
  const postedBy = tagByQa(card, "job-posted-by");
  const recruiterLink = postedBy?.match(/<a\b[^>]*>([\s\S]*?)<\/a>/i);
  return recruiterLink ? decodeHtml(recruiterLink[1] ?? "") || null : null;
}

function parseReedJobsCards(
  html: string,
  organisationName: string | null,
  limit: number,
): ReedVacancy[] {
  const cards = html
    .split(/<article\b/i)
    .slice(1)
    .map((chunk) => `<article${chunk.split(/<\/article>/i)[0] ?? ""}</article>`)
    .filter((card) => /data-qa=["']job-card["']/i.test(card));

  const vacancies: ReedVacancy[] = [];
  for (const card of cards) {
    const titleTag = tagByQa(card, "job-card-title");
    const employer = employerFromCard(card);
    if (!titleTag || !employer) continue;

    const title = decodeHtml(titleTag);
    if (!title || (organisationName && !employerNamesCloselyMatch(organisationName, employer))) continue;

    const href = titleTag.match(/\bhref=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/gi, "&");
    const externalListingId =
      card.match(/data-id=["']job(\d+)["']/i)?.[1] ??
      titleTag.match(/\bdata-id=["'](\d+)["']/i)?.[1];
    if (!href || !externalListingId) continue;

    const rawUrl = new URL(href, REED_BASE_URL).toString();
    const url = canonicalVacancyUrl(rawUrl);
    if (!url || !isValidJobBoardVacancyDeepLink(url)) continue;

    const postedBy = tagByQa(card, "job-posted-by");
    const postedDate = postedBy
      ? decodeHtml(postedBy).replace(/\s+by\s+[\s\S]*$/i, "").trim() || null
      : null;
    vacancies.push({
      title,
      employer,
      location: decodeHtml(tagByQa(card, "job-metadata-location") ?? "") || null,
      salary: decodeHtml(tagByQa(card, "job-metadata-salary") ?? "") || null,
      url,
      description: null,
      postedDate,
      targetRegions: null,
      sourceType: "job_board",
      boardName: "Reed",
      externalListingId,
      contactEmail: extractAdvertContactEmail(card, url),
      contactEvidenceUrl: url,
      ...(extractVacancyClosingDate(decodeHtml(card))
        ? { closesAt: extractVacancyClosingDate(decodeHtml(card)) }
        : {}),
    });
    if (vacancies.length >= limit) break;
  }
  return vacancies;
}

export function parseReedJobsHtml(html: string, organisationName: string): ReedVacancy[] {
  return parseReedJobsCards(html, organisationName, MAX_RESULTS);
}

export function parseReedCandidateJobsHtml(html: string, limit: number): ReedVacancy[] {
  return parseReedJobsCards(html, null, limit);
}

export async function searchReedJobs(organisationName: string): Promise<ReedSearchResult> {
  const sourceUrl = `${REED_BASE_URL}/jobs?keywords=${encodeURIComponent(organisationName)}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    await new Promise((resolve) => setTimeout(resolve, POLITE_REQUEST_DELAY_MS));
    const response = await fetch(sourceUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        Accept: "text/html,application/xhtml+xml",
        "Accept-Language": "en-GB,en;q=0.9",
        "User-Agent": "JOBSAGE vacancy discovery/1.0 (+https://jobsage.co.uk)",
      },
    });
    const contentType = response.headers.get("content-type") ?? "";
    if (!response.ok || !contentType.toLowerCase().includes("text/html")) {
      return {
        vacancies: [],
        sourceUrl,
        requestSucceeded: false,
        transientFailure: response.status === 403 || response.status === 429 || response.status >= 500,
      };
    }
    return {
      vacancies: parseReedJobsHtml(await response.text(), organisationName),
      sourceUrl,
      requestSucceeded: true,
      transientFailure: false,
    };
  } catch {
    return { vacancies: [], sourceUrl, requestSucceeded: false, transientFailure: true };
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Search Reed by profession keywords without applying the employer-name filter
 * used by the background employer adapter. Candidate discovery matches the
 * returned employer names to the sponsor register before persistence.
 */
export async function searchReedJobsForCandidate(
  keywords: string,
  region: string | null,
  limit = 40,
  deadlineMs?: number,
): Promise<ReedCandidateSearchResult> {
  const params = new URLSearchParams({ keywords });
  if (region) params.set("locationName", region);
  const sourceUrl = `${REED_BASE_URL}/jobs?${params.toString()}`;
  const vacancies: ReedVacancy[] = [];
  const urls = new Set<string>();

  for (let page = 1; page <= MAX_REED_CANDIDATE_PAGES && vacancies.length < limit; page++) {
    if (page > 1) await new Promise((resolve) => setTimeout(resolve, POLITE_REQUEST_DELAY_MS));
    const remainingMs = deadlineMs == null ? REQUEST_TIMEOUT_MS : deadlineMs - Date.now();
    if (remainingMs <= 0) {
      return { vacancies, sourceUrl, requestSucceeded: false, transientFailure: true };
    }
    const pageParams = new URLSearchParams(params);
    if (page > 1) pageParams.set("pageno", String(page));
    const pageUrl = `${REED_BASE_URL}/jobs?${pageParams.toString()}`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), Math.min(REQUEST_TIMEOUT_MS, remainingMs));
    try {
      const response = await fetch(pageUrl, {
        signal: controller.signal,
        redirect: "follow",
        headers: {
          Accept: "text/html,application/xhtml+xml",
          "Accept-Language": "en-GB,en;q=0.9",
          "User-Agent": "JOBSAGE vacancy discovery/1.0 (+https://jobsage.co.uk)",
        },
      });
      const contentType = response.headers.get("content-type") ?? "";
      if (!response.ok || !contentType.toLowerCase().includes("text/html")) {
        return {
          vacancies,
          sourceUrl,
          requestSucceeded: false,
          transientFailure: response.status === 403 || response.status === 429 || response.status >= 500,
        };
      }

      let added = 0;
      for (const vacancy of parseReedCandidateJobsHtml(await response.text(), limit)) {
        if (urls.has(vacancy.url)) continue;
        urls.add(vacancy.url);
        vacancies.push(vacancy);
        added += 1;
        if (vacancies.length >= limit) break;
      }
      if (added === 0) break;
    } catch {
      return { vacancies, sourceUrl, requestSucceeded: false, transientFailure: true };
    } finally {
      clearTimeout(timeout);
    }
  }

  return {
    vacancies,
    sourceUrl,
    requestSucceeded: true,
    transientFailure: false,
  };
}