# JOBSAGE Sponsor Website Vacancy Pipeline

This package adds a practical development-first route for populating company-website vacancies.

## What Changed

- Keeps existing Ashby, Greenhouse, and Lever direct-feed support.
- Adds public-feed adapters for SmartRecruiters, Recruitee, and Personio.
- Recognises more ATS/careers hosts so company websites that redirect to those systems are not treated as ordinary unknown pages.
- Falls back to already-fetched ATS HTML if a direct feed is unavailable.
- Adds `runSponsorWebsiteVacancyPipeline.ts`, a dev-only runner for reviewed website-enrichment CSVs.
- Adds `pnpm --filter @workspace/api-server vacancy:sponsor-websites`.

## Safe Operating Model

The runner has three lanes:

| Lane | Meaning | Writes in `--apply` mode |
|---|---|---|
| `auto_promote` | Explicitly approved, or high-confidence website row | Fill missing `sponsor_licences.website`, seed careers/ATS evidence, run collector |
| `review_required` | Medium/low/no confidence, unless explicitly approved | No write; exported to `review-required.csv` |
| `reject` | Invalid HTTPS URL or blocked job-board/aggregator host | No write; exported to `rejected.csv` |

It only runs when all of these are true:

- `NODE_ENV=development`
- `SPONSOR_WEBSITE_VACANCY_PIPELINE_DEV_DB=confirmed`
- `DATABASE_URL` is set

It does not run in production, send emails, submit applications, deploy, or copy dev data to production.

## Dry Run

```bash
NODE_ENV=development \
SPONSOR_WEBSITE_VACANCY_PIPELINE_DEV_DB=confirmed \
DATABASE_URL="$DATABASE_URL" \
pnpm --filter @workspace/api-server vacancy:sponsor-websites -- \
  --input ./jobsage-website-enrichment-candidates.csv \
  --out ./.agents/outputs/sponsor-website-vacancy-pipeline \
  --limit 100
```

This creates:

- `auto-promote-selected.csv`
- `review-required.csv`
- `rejected.csv`
- `report.json`
- `summary.md`

## Apply In Development

```bash
NODE_ENV=development \
SPONSOR_WEBSITE_VACANCY_PIPELINE_DEV_DB=confirmed \
DATABASE_URL="$DATABASE_URL" \
pnpm --filter @workspace/api-server vacancy:sponsor-websites -- \
  --input ./jobsage-website-enrichment-candidates.csv \
  --out ./.agents/outputs/sponsor-website-vacancy-pipeline \
  --limit 100 \
  --apply
```

Use `--accept-medium` only after you are comfortable treating medium-confidence rows as approved for the pilot. A safer alternative is adding a `decision` column with `approved` only on reviewed rows.

## Promotion To Production

Do not copy the whole development database to production. Promote only reviewed rows:

1. Run this in development.
2. Confirm `summary.md` and `report.json`.
3. Spot-check candidate-facing Opportunities for inserted vacancies.
4. Export the exact approved website/careers/ATS changes.
5. Apply a separate selective production import.
6. Let the existing hourly cron maintain the records after promotion.

## Verification Performed Locally

```bash
pnpm --filter @workspace/api-server typecheck
```

Passed.

```bash
DATABASE_URL=postgres://user:pass@127.0.0.1:5432/test \
pnpm --filter @workspace/api-server exec vitest run --config vitest.config.ts \
  src/__tests__/lib/directEmployerBoardConnectors.test.ts \
  src/__tests__/lib/companySiteDiscovery.test.ts \
  src/__tests__/lib/companySiteScheduler.test.ts \
  src/__tests__/lib/boardVacancyPipeline.test.ts
```

Passed: 4 files, 45 tests.

