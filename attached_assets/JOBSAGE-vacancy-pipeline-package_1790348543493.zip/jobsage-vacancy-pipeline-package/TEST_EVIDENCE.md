# JOBSAGE Vacancy Pipeline Test Evidence

Generated: 2026-09-25

## Environment Limit

This workspace does not have a `DATABASE_URL`, local Postgres, Docker, or Podman. The exact PostgreSQL write path can only be run when a development database URL is provided.

To compensate, testing covered:

- Real live public ATS feeds over the network.
- Real official employer website discovery over the network.
- The same JOBSAGE direct board parser, company-site discovery parser, normalization, dedupe, and scheduler-adjacent logic.
- Local SQLite evidence-store insert/update/repeat-import behavior.
- Sampled live detail/application URL checks.
- TypeScript compile and targeted Vitest coverage.

## Live Direct ATS Feed Test

Command:

```bash
node --use-env-proxy scripts/vacancy-lab/run.mjs live \
  .agents/inputs/live-sector-ats-smoke.json \
  .agents/outputs/live-sector-ats-smoke-verified
```

Result: passed.

| Sector | Employer | Provider | Raw | Normalized | UK-known | Repeat duplicate inserts |
|---|---:|---:|---:|---:|---:|---:|
| Finance | 9fin | Ashby | 33 | 33 | 25 | 0 |
| Finance | Monzo | Greenhouse | 71 | 71 | 52 | 0 |
| Technology-finance | GoCardless | Greenhouse | 28 | 28 | 10 | 0 |
| Hospitality/logistics | Deliveroo | Greenhouse | 146 | 141 | 90 | 0 |
| Finance | Wise | Greenhouse | 16 | 16 | 0 | 0 |
| Technology | Canonical | Greenhouse | 306 | 306 | 14 | 0 |
| Finance | Ebury | Greenhouse | 165 | 165 | 27 | 0 |
| Healthcare/social care | accuRx | Ashby | 14 | 14 | 14 | 0 |
| Education | Multiverse | Ashby | 17 | 16 | 16 | 0 |
| Engineering | Wayve | Greenhouse | 198 | 191 | 76 | 0 |
| Finance | Pliant Payments | Ashby | 36 | 36 | 3 | 0 |
| Healthcare/social care | Healios | Greenhouse | 5 | 5 | 0 | 0 |

Totals:

- 1,035 raw postings received.
- 1,022 normalized/stored vacancy records.
- 329 records with recognized UK location.
- Repeat same-batch import: 0 duplicate inserts, 1,022 updates.

## Live Official Website Discovery Test

Command:

```bash
node --use-env-proxy scripts/vacancy-lab/websites.mjs \
  .agents/inputs/live-sector-websites-smoke.json \
  .agents/outputs/live-sector-websites-smoke-after-fallback
```

Result: partial, with useful signal.

| Sector | Employer | Jobs found from official site | Completion | Main blocker |
|---|---:|---:|---|---|
| Finance | 9fin | 33 | complete | none |
| Finance | Monzo | 71 | complete | none |
| Technology-finance | GoCardless | 28 | complete | none |
| Hospitality/logistics | Deliveroo | 0 | failed | official `.co.uk` redirects outside current host scope |
| Finance | Wise | 0 | failed | site path returned 404 |
| Technology | Canonical | 57 | partial_page_limit | more pages remained after safe bounded crawl |
| Finance | Ebury | 0 | failed | robots policy unavailable |
| Healthcare/social care | accuRx | 0 | failed | root/common path 404, direct Ashby feed works |
| Education | Multiverse | 2 | complete | only surfaced two from root crawl, direct Ashby feed finds sixteen |
| Engineering | Wayve | 0 | failed | robots policy unavailable, direct Greenhouse feed works |
| Finance | Pliant Payments | 5 | partial_page_limit | more pages remained after safe bounded crawl |
| Healthcare/social care | Healios | 0 | failed | robots policy unavailable, direct Greenhouse feed works |

This proves root website crawling helps, but should not be the only route. Production should store verified careers/ATS mappings where possible, then direct feed extraction provides much stronger coverage.

## Live Link Checks

Sampled one stored vacancy/application URL from each of 10 employers:

- 9fin: 200
- Canonical: 200
- Deliveroo: 200
- GoCardless: 200
- Healios: 200
- Monzo: 200
- Multiverse: 200
- Pliant Payments: 200
- Wayve: 307
- accuRx: 200

Result: 10/10 reachable.

## Compile And Unit Coverage

```bash
pnpm --filter @workspace/api-server typecheck
```

Passed.

```bash
DATABASE_URL=postgres://user:pass@127.0.0.1:5432/test \
pnpm --filter @workspace/api-server exec vitest run --config vitest.config.ts \
  src/__tests__/lib/directEmployerBoardConnectors.test.ts \
  src/__tests__/lib/companySiteDiscovery.test.ts \
  src/__tests__/lib/companySiteScheduler.test.ts \
  src/__tests__/lib/boardVacancyPipeline.test.ts
```

Passed: 4 files, 45 tests.

## Verdict

This can work in production if the pipeline is tiered:

1. Use sponsor/employer website enrichment to find official websites.
2. Use official websites to discover careers/ATS URLs where possible.
3. Store verified careers/ATS mappings.
4. Prefer direct ATS feeds for vacancy population.
5. Use root HTML crawling as fallback, not the main population engine.
6. Let cron maintain/check after the initial development import/backfill.

The direct ATS path is strong. The root website crawler alone is not enough.

