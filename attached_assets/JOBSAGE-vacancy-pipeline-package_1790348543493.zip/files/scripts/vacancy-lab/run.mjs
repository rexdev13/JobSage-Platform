#!/usr/bin/env node
import './loader.mjs';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const { fetchDirectEmployerBoardCore } = await import('../../artifacts/api-server/src/lib/directEmployerBoardCore.ts');
const { normaliseAndDedupeBoardAdverts } = await import('../../artifacts/api-server/src/lib/boardVacancyNormalization.ts');
const { regionsFromLocationText } = await import('../../artifacts/api-server/src/lib/regionMatching.ts');
import { openStore } from './store.mjs';

export function parseCsv(text){
  const rows=[];let row=[],field='',quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}
    else if(c===','&&!quoted){row.push(field);field='';}
    else if(c==='\n'&&!quoted){row.push(field.replace(/\r$/,''));rows.push(row);row=[];field='';}
    else field+=c;
  }
  if(quoted)throw Error('Unclosed CSV quote');
  if(field||row.length){row.push(field.replace(/\r$/,''));rows.push(row);}
  const [head,...data]=rows;
  return data.filter(r=>r.some(Boolean)).map(r=>Object.fromEntries(head.map((h,i)=>[h,r[i]??''])));
}

// This portable diagnostic transport only accepts the four documented feed hosts.
// No redirects, arbitrary website fetching, DB writes or application submissions.
// The application wrapper still uses companySiteHttp and its production protections.
export async function liveTransport(url,deadline,maxBytes){
  const u=new URL(url);
  const permitted=new Set(['api.ashbyhq.com','boards-api.greenhouse.io','api.lever.co','api.eu.lever.co','api.smartrecruiters.com']);
  if(u.protocol!=='https:'||u.username||u.password||u.port||!permitted.has(u.hostname))
    if(!/^[a-z0-9-]+\\.(?:recruitee\\.com|jobs\\.personio\\.(?:de|com))$/i.test(u.hostname))
      return {ok:false,kind:'unsafe',reason:'Unsupported feed destination',failureClass:'permanent'};
  try{
    const response=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(Math.max(1,Math.min(15000,deadline-Date.now()))),headers:{'User-Agent':'JOBSAGE diagnostic/1.0'}});
    if(!response.ok){await response.body?.cancel();return {ok:false,kind:'http',status:response.status,reason:`HTTP ${response.status}`,failureClass:[404,410].includes(response.status)?'permanent':'temporary'};}
    let bytes=0;const chunks=[];
    for await(const chunk of response.body){bytes+=chunk.byteLength;if(bytes>maxBytes)throw Error('Response size limit exceeded');chunks.push(chunk);}
    return {ok:true,url:response.url,status:response.status,contentType:response.headers.get('content-type')??'',body:Buffer.concat(chunks).toString('utf8')};
  }catch(e){return {ok:false,kind:'network',reason:String(e.message),failureClass:'temporary'};}
}

const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function safeLink(url){try{const u=new URL(url);return u.protocol==='https:'&&!u.username&&!u.password?u.href:null;}catch{return null;}}
export function renderReport(report,jobs){
  const link=u=>safeLink(u)?`<a href="${escape(u)}" target="_blank" rel="noopener noreferrer">Open page</a>`:'—';
  return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>JOBSAGE collection evidence</title>
  <style>body{font:16px system-ui;max-width:1200px;margin:40px auto;padding:0 20px;color:#182535}h1{margin-bottom:8px}.notice{padding:18px;background:#fff0cc;border-left:5px solid #be7900}table{width:100%;border-collapse:collapse;margin:24px 0}td,th{padding:12px;border-bottom:1px solid #ddd;text-align:left}th{background:#eef3f8}pre{white-space:pre-wrap;overflow-wrap:anywhere}a{color:#075ca6}</style>
  <h1>JOBSAGE collection evidence</h1><p>${escape(report.createdAt)}</p>
  <p class="notice"><strong>${escape(report.mode==='replay'?'HISTORICAL REPLAY — NOT A LIVE COLLECTION':'LIVE FEED DIAGNOSTIC')}</strong><br>
  Production readiness: NOT ESTABLISHED. Page-content checks are reported separately below when available. PostgreSQL integration, candidate visibility and scheduler operation are not tested by this portable runner.</p>
  <p>${jobs.length} stored records · ${jobs.filter(j=>regionsFromLocationText(j.location).length).length} with a recognized UK region · ${report.applicationPagesContentVerified??0} application pages passed fresh content checks</p>
  <h2>Run results</h2><pre>${escape(JSON.stringify(report,null,2))}</pre>
  <h2>Stored vacancies</h2><table><thead><tr><th>Employer / role</th><th>Location</th><th>Details</th><th>Application</th><th>Evidence</th></tr></thead><tbody>
  ${jobs.map(j=>`<tr><td>${escape(j.employer)}<br><strong>${escape(j.title)}</strong></td><td>${escape(j.location)}</td><td>${link(j.detail_url)}</td><td>${link(j.application_url)}</td><td>${escape(j.evidence_mode)}<br>${report.applicationContentChecks?.rows?.some(r=>r.url===j.application_url&&r.result==="content_verified")?"Page content checked":"Page not checked in this run"}</td></tr>`).join('')}</tbody></table>`;
}

export async function run({mode='replay',input,out}){
  if(!['replay','live'].includes(mode))throw Error('Use replay or live mode');
  await mkdir(out,{recursive:true});
  const store=openStore(resolve(out,'vacancies.sqlite'));
  const start=Date.now();const report={createdAt:new Date().toISOString(),mode,productionReady:false,applicationPagesVerified:0,rows:[]};
  try{
    let employers,transport;
    if(mode==='replay'){
      const rows=parseCsv(await readFile(input,'utf8'));
      if(!rows.length||rows.some(r=>r.provider!=='Ashby'||!r.external_listing_id||!r.listing_url))throw Error('Replay requires the exported Ashby vacancy CSV');
      const board=rows[0].board_id;
      if(rows.some(r=>r.board_id!==board||r.employer_name!==rows[0].employer_name))throw Error('Replay expects one employer board');
      employers=[{companyName:rows[0].employer_name,atsProvider:'Ashby',savedCareersUrl:`https://jobs.ashbyhq.com/${board}`}];
      report.sourceCapture=rows[0].captured_at_utc;
      report.replayDisclosure='CSV records reconstructed into feed-shaped data. Original raw API response and full job descriptions were not provided. No network or fresh link checks.';
      transport=async url=>({ok:true,url,status:200,contentType:'application/json',body:JSON.stringify({jobs:rows.map(r=>({id:r.external_listing_id,title:r.title,location:r.source_location,jobUrl:r.listing_url,applyUrl:r.application_url,isListed:true}))})});
    }else{
      employers=JSON.parse(await readFile(input,'utf8')).employers;
      if(!Array.isArray(employers)||!employers.length||employers.length>20)throw Error('Supply 1–20 employer records');
      let captureIndex=0;
      report.captures=[];
      await mkdir(resolve(out,'captures'),{recursive:true});
      transport=async (...args)=>{
        const result=await liveTransport(...args);
        const capture={url:args[0],fetchedAt:new Date().toISOString(),ok:result.ok,status:result.status??null};
        if(result.ok){
          capture.file=`captures/feed-${++captureIndex}.json`;
          capture.sha256=createHash('sha256').update(result.body).digest('hex');
          await writeFile(resolve(out,capture.file),result.body);
        }
        report.captures.push(capture);return result;
      };
      report.transport='Bounded public feed diagnostic; production companySiteHttp must still be tested in Replit';
    }
    for(const employer of employers){
      const t=Date.now();
      const scan=await fetchDirectEmployerBoardCore(employer.companyName,employer.atsProvider,employer.savedCareersUrl??employer.officialCareersUrl,transport,{deadlineMs:Date.now()+25000});
      const normalized=normaliseAndDedupeBoardAdverts(scan.adverts);
      const row={employer:employer.companyName,complete:scan.complete,error:scan.error??null,received:scan.adverts.length,normalized:normalized.length,knownUkRegion:normalized.filter(a=>regionsFromLocationText(a.location).length).length,elapsedMs:Date.now()-t};
      if(scan.mapping){row.persisted=store.save(normalized,scan.mapping,mode);row.repeatSameBatch=store.save(normalized,scan.mapping,mode);}
      // Failure never removes old rows and never changes an old replay to live evidence.
      report.rows.push(row);
      console.log(JSON.stringify(row));
    }
    report.elapsedMs=Date.now()-start;
    report.totalStored=store.jobs().length;
    report.freshLiveRecords=mode==='live'?report.rows.reduce((n,r)=>n+r.received,0):0;
    report.liveFeedCheckPassed=mode==='live'&&report.rows.every(r=>r.complete)&&report.freshLiveRecords>0;
    report.replayCheckPassed=mode==='replay'&&report.rows.every(r=>r.complete&&r.received>0&&r.repeatSameBatch?.inserted===0);
    store.report(report);
    await writeFile(resolve(out,'report.json'),JSON.stringify(report,null,2));
    await writeFile(resolve(out,'report.html'),renderReport(report,store.jobs()));
    return report;
  }finally{store.close();}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const [mode='replay',input,out=`vacancy-lab-${mode}`]=process.argv.slice(2);
  if(!input){console.error('Usage: node --use-env-proxy scripts/vacancy-lab/run.mjs replay|live INPUT OUTPUT_DIR');process.exitCode=1;}
  else run({mode,input,out}).then(r=>{console.log(`Report: ${resolve(out,'report.html')}`);if(mode==='live'&&!r.liveFeedCheckPassed)process.exitCode=2;}).catch(e=>{console.error(e);process.exitCode=1;});
}
