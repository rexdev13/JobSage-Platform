/**
 * Development-only sponsor website -> vacancy acceptance runner.
 *
 * Input is a reviewed website-enrichment CSV. The runner can:
 * - classify rows into auto/review/reject
 * - optionally fill missing sponsor_licences.website values in development
 * - run the existing company-site/ATS vacancy collector immediately
 * - write JSON/CSV reports that show what was imported and what failed
 *
 * It never runs in production and never sends applications/emails/deploys.
 */
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { db, pool } from "@workspace/db";
import { sql } from "drizzle-orm";
import {
  runCompanySiteCheck,
  type CompanySiteCheckOutcome,
} from "../lib/companySiteScheduler";
import { knownAtsProvider } from "../lib/companySiteDestinationPolicy";

type CsvRow = Record<string, string>;

type Candidate = {
  sponsorLicenceId: number;
  organisationName: string;
  websiteUrl: string;
  websiteConfidence: string;
  websiteEvidenceUrl: string | null;
  careersUrl: string | null;
  careersConfidence: string;
  atsProvider: string | null;
  atsMappingStatus: string | null;
  atsMappingEvidenceUrl: string | null;
  source: string | null;
  notes: string | null;
  decision: "auto_promote" | "review_required" | "reject";
  reason: string;
};

const BLOCKED_HOST_PARTS = [
  "indeed.",
  "reed.",
  "totaljobs.",
  "cv-library.",
  "linkedin.",
  "glassdoor.",
  "jooble.",
  "adzuna.",
  "findajob.dwp.gov.uk",
  "nhsjobs.",
  "jobs.nhs.uk",
];

function parseArgs(): {
  input: string;
  outputDir: string;
  limit: number;
  apply: boolean;
  acceptMedium: boolean;
} {
  const args = process.argv.slice(2);
  const config = {
    input: "",
    outputDir: "sponsor-website-vacancy-pipeline",
    limit: 50,
    apply: false,
    acceptMedium: false,
  };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === "--input") config.input = args[++index] ?? "";
    else if (arg === "--out") config.outputDir = args[++index] ?? config.outputDir;
    else if (arg === "--limit") config.limit = Number.parseInt(args[++index] ?? "", 10);
    else if (arg === "--apply") config.apply = true;
    else if (arg === "--accept-medium") config.acceptMedium = true;
    else if (!config.input) config.input = arg;
  }
  if (!config.input) throw new Error("Supply --input reviewed-website-candidates.csv");
  config.outputDir = resolve(config.outputDir);
  config.limit = Number.isFinite(config.limit) ? Math.max(1, Math.min(config.limit, 500)) : 50;
  return config;
}

function parseCsv(text: string): CsvRow[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (char === "\"") {
      if (quoted && text[index + 1] === "\"") {
        field += "\"";
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === "," && !quoted) {
      row.push(field);
      field = "";
    } else if (char === "\n" && !quoted) {
      row.push(field.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (quoted) throw new Error("CSV has an unclosed quote");
  if (field || row.length > 0) {
    row.push(field.replace(/\r$/, ""));
    rows.push(row);
  }
  const header = rows.shift()?.map((value) => value.trim()) ?? [];
  return rows
    .filter((values) => values.some((value) => value.trim() !== ""))
    .map((values) => Object.fromEntries(header.map((key, index) => [key, values[index] ?? ""])));
}

function csvEscape(value: unknown): string {
  const text = String(value ?? "");
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, "\"\"")}"` : text;
}

function writeCsv(rows: readonly Record<string, unknown>[]): string {
  const headers = [...new Set(rows.flatMap((row) => Object.keys(row)))];
  return [
    headers.map(csvEscape).join(","),
    ...rows.map((row) => headers.map((header) => csvEscape(row[header])).join(",")),
  ].join("\n");
}

function validHttpsUrl(value: string | null | undefined): string | null {
  const raw = value?.trim();
  if (!raw) return null;
  try {
    const url = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (url.protocol !== "https:" || url.username || url.password) return null;
    url.hash = "";
    return url.toString();
  } catch {
    return null;
  }
}

function isBlockedWebsite(url: string): boolean {
  const host = new URL(url).hostname.toLowerCase();
  return BLOCKED_HOST_PARTS.some((part) => host.includes(part));
}

function rowDecision(
  row: CsvRow,
  websiteUrl: string | null,
  acceptMedium: boolean,
): Pick<Candidate, "decision" | "reason"> {
  const explicit = (row["decision"] ?? row["approved"] ?? "").trim().toLowerCase();
  if (["approve", "approved", "yes", "true", "auto_promote"].includes(explicit)) {
    return { decision: "auto_promote", reason: "explicitly approved in CSV" };
  }
  if (!websiteUrl) return { decision: "reject", reason: "missing or invalid HTTPS website" };
  if (isBlockedWebsite(websiteUrl)) return { decision: "reject", reason: "job board or aggregator host" };
  const confidence = (row["website_confidence"] ?? row["confidence"] ?? "").trim().toLowerCase();
  if (confidence === "high") return { decision: "auto_promote", reason: "high-confidence website candidate" };
  if (acceptMedium && confidence === "medium") {
    return { decision: "auto_promote", reason: "medium-confidence accepted by operator flag" };
  }
  return { decision: "review_required", reason: confidence ? `${confidence}-confidence candidate` : "no confidence supplied" };
}

function toCandidate(row: CsvRow, acceptMedium: boolean): Candidate | null {
  const sponsorLicenceId = Number.parseInt(row["sponsor_licence_id"] ?? row["id"] ?? "", 10);
  const organisationName = (row["organisation_name"] ?? row["companyName"] ?? row["company_name"] ?? "").trim();
  const websiteUrl = validHttpsUrl(row["website_url"] ?? row["existing_website"] ?? row["website"]);
  if (!Number.isSafeInteger(sponsorLicenceId) || sponsorLicenceId <= 0 || !organisationName) return null;
  const decision = rowDecision(row, websiteUrl, acceptMedium);
  const careersUrl = validHttpsUrl(row["careers_url"] ?? row["existing_careers_url"]);
  return {
    sponsorLicenceId,
    organisationName,
    websiteUrl: websiteUrl ?? "",
    websiteConfidence: row["website_confidence"] ?? "",
    websiteEvidenceUrl: validHttpsUrl(row["website_evidence_url"]),
    careersUrl,
    careersConfidence: row["careers_confidence"] ?? "",
    atsProvider: (row["ats_provider"] ?? row["existing_ats_provider"] ?? "").trim() || (careersUrl ? knownAtsProvider(careersUrl) : null),
    atsMappingStatus: (row["ats_mapping_status"] ?? row["existing_ats_mapping_status"] ?? "").trim() || null,
    atsMappingEvidenceUrl: validHttpsUrl(row["ats_mapping_evidence_url"] ?? row["existing_ats_mapping_evidence_url"]),
    source: (row["source"] ?? "").trim() || null,
    notes: (row["notes"] ?? "").trim() || null,
    ...decision,
  };
}

async function getCurrentSponsorState(candidate: Candidate): Promise<{
  existingWebsite: string | null;
  existingCareersUrl: string | null;
  existingAtsProvider: string | null;
  genericCheckedAt: Date | null;
  atsCheckedAt: Date | null;
  crawlState: {
    queue: string[];
    visited: string[];
    sitemapQueued?: boolean;
    observedAdvertUrls?: string[];
    hadFailure?: boolean;
    directOffset?: number;
    careersUrl?: string | null;
    atsProvider?: string | null;
  } | null;
} | null> {
  const result = await db.execute<{
    website: string | null;
    careers_url: string | null;
    ats_provider: string | null;
    generic_checked_at: Date | null;
    ats_checked_at: Date | null;
    crawl_state: null | {
      queue: string[];
      visited: string[];
      sitemapQueued?: boolean;
      observedAdvertUrls?: string[];
      hadFailure?: boolean;
      directOffset?: number;
      careersUrl?: string | null;
      atsProvider?: string | null;
    };
  }>(sql`
    SELECT
      sl.website,
      cs.careers_url,
      cs.ats_provider,
      cs.generic_checked_at,
      cs.ats_checked_at,
      cs.crawl_state
    FROM sponsor_licences sl
    LEFT JOIN sponsor_licence_company_site_checks cs
      ON lower(btrim(cs.organisation_name)) = lower(btrim(sl.organisation_name))
    WHERE sl.id = ${candidate.sponsorLicenceId}
      AND lower(btrim(sl.organisation_name)) = lower(btrim(${candidate.organisationName}))
    LIMIT 1
  `);
  const row = result.rows[0];
  if (!row) return null;
  return {
    existingWebsite: row.website ?? null,
    existingCareersUrl: row.careers_url ?? null,
    existingAtsProvider: row.ats_provider ?? null,
    genericCheckedAt: row.generic_checked_at ? new Date(row.generic_checked_at) : null,
    atsCheckedAt: row.ats_checked_at ? new Date(row.ats_checked_at) : null,
    crawlState: row.crawl_state ?? null,
  };
}

async function promoteCandidate(candidate: Candidate): Promise<"filled" | "existing" | "missing_sponsor"> {
  const result = await db.execute(sql`
    UPDATE sponsor_licences
    SET website = COALESCE(NULLIF(btrim(website), ''), ${candidate.websiteUrl})
    WHERE id = ${candidate.sponsorLicenceId}
      AND lower(btrim(organisation_name)) = lower(btrim(${candidate.organisationName}))
    RETURNING website
  `);
  if (result.rows.length === 0) return "missing_sponsor";
  return "filled";
}

async function seedCompanySiteEvidence(candidate: Candidate): Promise<void> {
  if (!candidate.careersUrl && !candidate.atsProvider) return;
  await db.execute(sql`
    INSERT INTO sponsor_licence_company_site_checks
      (organisation_name, careers_url, ats_provider, ats_mapping_evidence_url,
       ats_mapping_status, last_attempted_at, updated_at)
    VALUES (
      ${candidate.organisationName},
      ${candidate.careersUrl},
      ${candidate.atsProvider},
      ${candidate.atsMappingEvidenceUrl ?? candidate.careersUrl},
      ${candidate.atsMappingStatus === "verified" ? "verified" : "unverified"},
      NOW(),
      NOW()
    )
    ON CONFLICT (organisation_name) DO UPDATE SET
      careers_url = COALESCE(sponsor_licence_company_site_checks.careers_url, EXCLUDED.careers_url),
      ats_provider = COALESCE(sponsor_licence_company_site_checks.ats_provider, EXCLUDED.ats_provider),
      ats_mapping_evidence_url = COALESCE(sponsor_licence_company_site_checks.ats_mapping_evidence_url, EXCLUDED.ats_mapping_evidence_url),
      ats_mapping_status = CASE
        WHEN sponsor_licence_company_site_checks.ats_mapping_status = 'verified'
          THEN sponsor_licence_company_site_checks.ats_mapping_status
        ELSE EXCLUDED.ats_mapping_status
      END,
      updated_at = NOW()
  `);
}

async function main(): Promise<void> {
  if (
    process.env.NODE_ENV !== "development" ||
    process.env.SPONSOR_WEBSITE_VACANCY_PIPELINE_DEV_DB !== "confirmed" ||
    !process.env.DATABASE_URL
  ) {
    throw new Error("Use only with a development DB: set NODE_ENV=development and SPONSOR_WEBSITE_VACANCY_PIPELINE_DEV_DB=confirmed.");
  }
  const args = parseArgs();
  await mkdir(args.outputDir, { recursive: true });
  const candidates = parseCsv(await readFile(args.input, "utf8"))
    .map((row) => toCandidate(row, args.acceptMedium))
    .filter((candidate): candidate is Candidate => candidate !== null);
  const auto = candidates
    .filter((candidate) => candidate.decision === "auto_promote")
    .slice(0, args.limit);
  const review = candidates.filter((candidate) => candidate.decision === "review_required");
  const rejected = candidates.filter((candidate) => candidate.decision === "reject");

  const rows: Array<Record<string, unknown>> = [];
  const report = {
    createdAt: new Date().toISOString(),
    developmentOnly: true,
    apply: args.apply,
    input: resolve(args.input),
    totals: {
      candidates: candidates.length,
      autoPromoteSelected: auto.length,
      reviewRequired: review.length,
      rejected: rejected.length,
      websitesFilled: 0,
      employersChecked: 0,
      vacanciesInserted: 0,
      vacanciesUpdated: 0,
      vacanciesRevived: 0,
      vacanciesFound: 0,
      errors: 0,
    },
    rows,
  };
  await writeFile(resolve(args.outputDir, "review-required.csv"), writeCsv(review));
  await writeFile(resolve(args.outputDir, "rejected.csv"), writeCsv(rejected));

  try {
    for (const candidate of auto) {
      const started = Date.now();
      const row: Record<string, unknown> = {
        sponsorLicenceId: candidate.sponsorLicenceId,
        organisationName: candidate.organisationName,
        websiteUrl: candidate.websiteUrl,
        careersUrl: candidate.careersUrl,
        atsProvider: candidate.atsProvider,
        decisionReason: candidate.reason,
      };
      try {
        const state = await getCurrentSponsorState(candidate);
        if (!state) {
          row.status = "missing_sponsor";
          report.totals.errors += 1;
          rows.push(row);
          continue;
        }
        row.previousWebsite = state.existingWebsite;
        if (args.apply) {
          const promoted = await promoteCandidate(candidate);
          row.websitePromotion = promoted;
          if (promoted === "filled") report.totals.websitesFilled += 1;
          await seedCompanySiteEvidence(candidate);
          const outcome: CompanySiteCheckOutcome = await runCompanySiteCheck({
            organisationName: candidate.organisationName,
            website: state.existingWebsite?.trim() || candidate.websiteUrl,
            genericCheckedAt: null,
            atsCheckedAt: null,
            careersUrl: candidate.careersUrl ?? state.existingCareersUrl,
            atsProvider: candidate.atsProvider ?? state.existingAtsProvider,
            crawlState: state.crawlState,
          }, {
            deadlineMs: Date.now() + 60_000,
            acquireLease: true,
            deferVerification: true,
          });
          row.collection = outcome;
          report.totals.employersChecked += 1;
          if (outcome.status === "checked") {
            report.totals.vacanciesFound += outcome.adverts;
            report.totals.vacanciesInserted += outcome.inserted;
            report.totals.vacanciesUpdated += outcome.updated;
            report.totals.vacanciesRevived += outcome.revived;
          }
        } else {
          row.status = "dry_run";
        }
      } catch (error) {
        row.error = error instanceof Error ? error.message : String(error);
        report.totals.errors += 1;
      }
      row.elapsedMs = Date.now() - started;
      rows.push(row);
      await writeFile(resolve(args.outputDir, "report.json"), JSON.stringify(report, null, 2));
      console.log(JSON.stringify(row));
    }
    await writeFile(resolve(args.outputDir, "auto-promote-selected.csv"), writeCsv(auto));
    await writeFile(resolve(args.outputDir, "report.json"), JSON.stringify(report, null, 2));
    await writeFile(resolve(args.outputDir, "summary.md"), [
      "# Sponsor Website Vacancy Pipeline",
      "",
      `Generated: ${report.createdAt}`,
      "",
      `Mode: ${args.apply ? "development apply" : "dry-run only"}`,
      "",
      `- Candidates read: ${report.totals.candidates}`,
      `- Auto-promote selected: ${report.totals.autoPromoteSelected}`,
      `- Review required: ${report.totals.reviewRequired}`,
      `- Rejected: ${report.totals.rejected}`,
      `- Websites filled: ${report.totals.websitesFilled}`,
      `- Employers checked: ${report.totals.employersChecked}`,
      `- Vacancies found: ${report.totals.vacanciesFound}`,
      `- Vacancies inserted: ${report.totals.vacanciesInserted}`,
      `- Vacancies updated: ${report.totals.vacanciesUpdated}`,
      `- Vacancies revived: ${report.totals.vacanciesRevived}`,
      `- Errors: ${report.totals.errors}`,
      "",
      "Review `review-required.csv` before using `--accept-medium` or adding an explicit `decision=approved` column.",
      "",
    ].join("\n"));
    console.log(`Wrote report to ${resolve(args.outputDir, "summary.md")}`);
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
