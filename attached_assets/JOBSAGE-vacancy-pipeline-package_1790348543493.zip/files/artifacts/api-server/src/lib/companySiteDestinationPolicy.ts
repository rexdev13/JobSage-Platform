import type { CompanySiteFetchFailure, CompanySiteFailureClass } from "./companySiteHttp";
const ATS_HOSTS: Array<{ provider: string; suffix: string }> = [
  { provider: "Greenhouse", suffix: "greenhouse.io" },
  { provider: "Lever", suffix: "lever.co" },
  { provider: "Workday", suffix: "myworkdayjobs.com" },
  { provider: "SmartRecruiters", suffix: "smartrecruiters.com" },
  { provider: "Oracle Recruiting", suffix: "oraclecloud.com" },
  { provider: "Taleo", suffix: "taleo.net" },
  { provider: "Pinpoint", suffix: "pinpointhq.com" },
  { provider: "SAP SuccessFactors", suffix: "successfactors.com" },
  { provider: "Ashby", suffix: "ashbyhq.com" },
  { provider: "BambooHR", suffix: "bamboohr.com" },
  { provider: "Recruitee", suffix: "recruitee.com" },
  { provider: "Personio", suffix: "jobs.personio.de" },
  { provider: "Personio", suffix: "jobs.personio.com" },
  { provider: "Teamtailor", suffix: "teamtailor.com" },
  { provider: "Workable", suffix: "workable.com" },
  { provider: "iCIMS", suffix: "icims.com" },
];

export function classifyCompanySiteFailure(input: {
  kind: CompanySiteFetchFailure;
  reason: string;
  status?: number;
}): CompanySiteFailureClass {
  if (input.kind === "unsafe") return "permanent";
  if (input.status === 404 || input.status === 410) return "permanent";
  if (
    input.kind === "http" &&
    input.status != null &&
    input.status >= 400 &&
    input.status < 500 &&
    input.status !== 403 &&
    input.status !== 429
  ) {
    return "permanent";
  }
  if (
    input.kind === "network" &&
    /(CERT_HAS_EXPIRED|ERR_TLS_CERT_ALTNAME_INVALID|DEPTH_ZERO_SELF_SIGNED_CERT|UNABLE_TO_VERIFY_LEAF_SIGNATURE|ERR_TLS_CERT_INVALID|certificate has expired|certificate.*(name|verify|authority))/i.test(
      input.reason,
    )
  ) {
    return "permanent";
  }
  if (
    input.kind === "network" &&
    /(ENOTFOUND|EAI_NONAME|NXDOMAIN|name or service not known)/i.test(input.reason)
  ) {
    return "permanent";
  }
  return "temporary";
}

export function normaliseHostname(hostname: string): string {
  return hostname.trim().toLowerCase().replace(/\.$/, "");
}

export function withoutWww(hostname: string): string {
  return normaliseHostname(hostname).replace(/^www\./, "");
}

export function knownAtsProvider(urlOrHostname: string): string | null {
  let hostname = urlOrHostname;
  try {
    hostname = new URL(urlOrHostname).hostname;
  } catch {
    // The caller may already have supplied a hostname.
  }
  const host = normaliseHostname(hostname);
  return ATS_HOSTS.find(({ suffix }) => host === suffix || host.endsWith(`.${suffix}`))?.provider ?? null;
}

export function isAllowedCompanyDestination(originHostname: string, candidateUrl: string): boolean {
  let candidate: URL;
  try {
    candidate = new URL(candidateUrl);
  } catch {
    return false;
  }
  if (candidate.protocol !== "http:" && candidate.protocol !== "https:") return false;
  const origin = withoutWww(originHostname);
  const target = withoutWww(candidate.hostname);
  return (
    target === origin ||
    target.endsWith(`.${origin}`) ||
    origin.endsWith(`.${target}`) ||
    knownAtsProvider(target) !== null
  );
}
