import type { CompanySiteFailureClass, CompanySiteFetchResult } from "./companySiteHttp";
import type { BoardAdvert } from "./boardVacancyPipeline";

export type DirectBoardProvider =
  | "Ashby"
  | "Greenhouse"
  | "Lever"
  | "SmartRecruiters"
  | "Recruitee"
  | "Personio";

export type DirectBoardMapping = {
  provider: DirectBoardProvider;
  boardId: string;
  evidenceUrl: string;
  feedUrl: string;
};

export type DirectBoardScan = {
  adverts: BoardAdvert[];
  mapping: DirectBoardMapping | null;
  complete: boolean;
  transientFailure: boolean;
  failureClass: CompanySiteFailureClass | null;
  retryAt?: Date;
  error?: string;
  pagesFetched: number;
  advertsExtracted: number;
  excludedUnlisted: number;
  nextOffset?: number;
};

const ASHBY_HOST = /^(?:www\.)?jobs\.ashbyhq\.com$/i;
const GREENHOUSE_HOST = /^(?:boards|job-boards)(?:\.eu)?\.greenhouse\.io$/i;
const LEVER_HOST = /^jobs(?:\.eu)?\.lever\.co$/i;
const SMARTRECRUITERS_HOST = /^jobs\.smartrecruiters\.com$/i;
const RECRUITEE_HOST = /^[a-z0-9-]+\.recruitee\.com$/i;
const PERSONIO_HOST = /^[a-z0-9-]+\.jobs\.personio\.(?:de|com)$/i;

function strictBoardId(value: string): string | null {
  const id = value.trim();
  return /^[a-z0-9][a-z0-9._-]{1,120}$/i.test(id) ? id : null;
}

export function parseDirectBoardMapping(
  provider: string | null | undefined,
  savedCareersUrl: string | null | undefined,
): DirectBoardMapping | null {
  if (!savedCareersUrl) return null;
  let parsed: URL;
  try {
    parsed = new URL(savedCareersUrl);
  } catch {
    return null;
  }
  if (parsed.protocol != "https:" || parsed.username || parsed.password) return null;
  const path = parsed.pathname.replace(/^\/|\/$/g, "");
  const selected = provider?.trim().toLowerCase();
  if (selected === "ashby" && ASHBY_HOST.test(parsed.hostname)) {
    const segments = path.split("/").filter(Boolean);
    const boardId = strictBoardId(segments[0] ?? "");
    const isBoardRoot = segments.length === 1;
    const isTalentCommunityEvidence =
      segments.length === 3 &&
      segments[1]?.toLowerCase() === "form" &&
      segments[2]?.toLowerCase() === "talent-community";
    if (!isBoardRoot && !isTalentCommunityEvidence) return null;
    if (!boardId) return null;
    return {
      provider: "Ashby",
      boardId,
      evidenceUrl: parsed.toString(),
      feedUrl: `https://api.ashbyhq.com/posting-api/job-board/${encodeURIComponent(boardId)}`,
    };
  }
  if (selected === "greenhouse" && GREENHOUSE_HOST.test(parsed.hostname)) {
    const boardId = strictBoardId(path);
    if (!boardId) return null;
    return {
      provider: "Greenhouse",
      boardId,
      evidenceUrl: parsed.toString(),
      feedUrl: `https://boards-api.greenhouse.io/v1/boards/${encodeURIComponent(boardId)}/jobs?content=false`,
    };
  }
  if (selected === "lever" && LEVER_HOST.test(parsed.hostname)) {
    const boardId = strictBoardId(path);
    if (!boardId) return null;
    return {
      provider: "Lever",
      boardId,
      evidenceUrl: parsed.toString(),
      feedUrl: `https://${parsed.hostname.toLowerCase().includes(".eu.") ? "api.eu.lever.co" : "api.lever.co"}/v0/postings/${encodeURIComponent(boardId)}?mode=json&limit=100&skip=0`,
    };
  }
  if (selected === "smartrecruiters" && SMARTRECRUITERS_HOST.test(parsed.hostname)) {
    const boardId = strictBoardId(path.split("/").filter(Boolean)[0] ?? "");
    if (!boardId) return null;
    return {
      provider: "SmartRecruiters",
      boardId,
      evidenceUrl: parsed.toString(),
      feedUrl: `https://api.smartrecruiters.com/v1/companies/${encodeURIComponent(boardId)}/postings?limit=100&offset=0`,
    };
  }
  if (selected === "recruitee" && RECRUITEE_HOST.test(parsed.hostname)) {
    const boardId = strictBoardId(parsed.hostname.split(".")[0] ?? "");
    if (!boardId) return null;
    return {
      provider: "Recruitee",
      boardId,
      evidenceUrl: parsed.toString(),
      feedUrl: `https://${parsed.hostname}/api/offers/`,
    };
  }
  if (selected === "personio" && PERSONIO_HOST.test(parsed.hostname)) {
    const boardId = strictBoardId(parsed.hostname.split(".")[0] ?? "");
    if (!boardId) return null;
    return {
      provider: "Personio",
      boardId,
      evidenceUrl: parsed.toString(),
      feedUrl: `${parsed.origin}/xml`,
    };
  }
  return null;
}

function text(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function identifier(value: unknown): string | null {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0
    ? String(value) : text(value);
}

function timestamp(value: unknown): string | null {
  if (typeof value === "number" && Number.isFinite(value)) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
  }
  return text(value);
}

function stripHtml(value: string): string {
  return value
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function stripXml(value: string): string {
  return stripHtml(value)
    .replace(/<!\[CDATA\[|\]\]>/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function locationText(value: unknown): string | null {
  if (typeof value === "string") return text(value);
  if (!value || typeof value !== "object") return null;
  const record = value as Record<string, unknown>;
  return [record.name, record.city, record.region, record.country]
    .filter((part): part is string => typeof part === "string" && part.trim() !== "")
    .join(", ") || null;
}

function smartRecruitersLocation(value: unknown): string | null {
  if (!value || typeof value !== "object") return null;
  const record = value as Record<string, unknown>;
  return [record.city, record.region, record.country]
    .filter((part): part is string => typeof part === "string" && part.trim() !== "")
    .join(", ") || null;
}

function firstText(record: Record<string, unknown>, keys: readonly string[]): string | null {
  for (const key of keys) {
    const value = text(record[key]);
    if (value) return value;
  }
  return null;
}

function advert(
  organisationName: string,
  provider: DirectBoardProvider,
  id: string,
  title: string,
  url: string,
  applicationUrl: string | null,
  description: string | null,
  location: string | null,
  postedDate: string | null,
  evidenceUrl: string,
): BoardAdvert {
  return {
    organisationName,
    employer: organisationName,
    title,
    location,
    salary: null,
    url,
    applicationUrl,
    description,
    postedDate,
    targetRegions: null,
    boardName: null,
    externalId: id,
    sourceType: "company_site",
    companyVacancyEvidence: {
      kind: "known_ats_posting",
      provider,
      listingUrl: evidenceUrl,
    },
  };
}

function parseJson(body: string): unknown {
  try {
    return JSON.parse(body);
  } catch {
    throw new Error("direct board returned malformed JSON");
  }
}

function parseAshby(
  organisationName: string,
  mapping: DirectBoardMapping,
  body: string,
): { adverts: BoardAdvert[]; excludedUnlisted: number } {
  const jobs = (parseJson(body) as { jobs?: unknown }).jobs;
  if (!Array.isArray(jobs)) throw new Error("Ashby response did not contain a jobs array");
  let excludedUnlisted = 0;
  const adverts = jobs.flatMap((raw): BoardAdvert[] => {
    if (!raw || typeof raw !== "object") throw new Error("Malformed job entry: snapshot is incomplete");
    const job = raw as Record<string, unknown>;
    if (job.isListed === false) {
      excludedUnlisted++;
      return [];
    }
    const id = identifier(job.id);
    const title = text(job.title);
    const url = text(job.jobUrl);
    if (!id || !title || !url) throw new Error("Missing job identity/title/URL: snapshot is incomplete");
    return [advert(
      organisationName,
      "Ashby",
      id,
      title,
      url,
      text(job.applyUrl),
      text(job.descriptionPlain) ?? (text(job.descriptionHtml) ? stripHtml(text(job.descriptionHtml)!) : null),
      locationText(job.location),
      text(job.publishedAt),
      mapping.evidenceUrl,
    )];
  });
  return { adverts, excludedUnlisted };
}

function parseGreenhouse(
  organisationName: string,
  mapping: DirectBoardMapping,
  body: string,
): { adverts: BoardAdvert[]; excludedUnlisted: number } {
  const payload = parseJson(body) as { jobs?: unknown; meta?: { total?: number } };
  const jobs = payload.jobs;
  if (!Array.isArray(jobs)) throw new Error("Greenhouse response did not contain a jobs array");
  if (typeof payload.meta?.total === "number" && payload.meta.total !== jobs.length) {
    throw new Error("Greenhouse total does not match returned jobs: snapshot is incomplete");
  }
  const adverts = jobs.flatMap((raw): BoardAdvert[] => {
    if (!raw || typeof raw !== "object") throw new Error("Malformed job entry: snapshot is incomplete");
    const job = raw as Record<string, unknown>;
    const id = identifier(job.id);
    const title = text(job.title);
    const url = text(job.absolute_url);
    if (!id || !title || !url) throw new Error("Missing job identity/title/URL: snapshot is incomplete");
    return [advert(
      organisationName,
      "Greenhouse",
      id,
      title,
      url,
      null,
      text(job.content) ? stripHtml(text(job.content)!) : null,
      locationText(job.location),
      text(job.updated_at) ?? text(job.first_published),
      mapping.evidenceUrl,
    )];
  });
  return { adverts, excludedUnlisted: 0 };
}

function parseLever(
  organisationName: string,
  mapping: DirectBoardMapping,
  body: string,
): { adverts: BoardAdvert[]; excludedUnlisted: number } {
  const jobs = parseJson(body);
  if (!Array.isArray(jobs)) throw new Error("Lever response did not contain a postings array");
  const adverts = jobs.flatMap((raw): BoardAdvert[] => {
    if (!raw || typeof raw !== "object") throw new Error("Malformed job entry: snapshot is incomplete");
    const job = raw as Record<string, unknown>;
    const id = identifier(job.id);
    const title = text(job.text);
    const url = text(job.hostedUrl) ?? text(job.applyUrl);
    if (!id || !title || !url) throw new Error("Missing job identity/title/URL: snapshot is incomplete");
    const categories = job.categories;
    const location = categories && typeof categories === "object"
      ? locationText((categories as Record<string, unknown>).location)
      : null;
    return [advert(
      organisationName,
      "Lever",
      id,
      title,
      url,
      text(job.applyUrl),
      text(job.descriptionPlain) ?? (text(job.description) ? stripHtml(text(job.description)!) : null),
      location,
      timestamp(job.createdAt) ?? timestamp(job.updatedAt),
      mapping.evidenceUrl,
    )];
  });
  return { adverts, excludedUnlisted: 0 };
}

function parseSmartRecruiters(
  organisationName: string,
  mapping: DirectBoardMapping,
  body: string,
): { adverts: BoardAdvert[]; excludedUnlisted: number } {
  const payload = parseJson(body) as { content?: unknown; postings?: unknown; totalFound?: number; total?: number };
  const jobs = Array.isArray(payload.content)
    ? payload.content
    : Array.isArray(payload.postings)
      ? payload.postings
      : [];
  if (!Array.isArray(jobs)) throw new Error("SmartRecruiters response did not contain a postings array");
  const adverts = jobs.flatMap((raw): BoardAdvert[] => {
    if (!raw || typeof raw !== "object") throw new Error("Malformed posting entry: snapshot is incomplete");
    const job = raw as Record<string, unknown>;
    const id = identifier(job.id ?? job.uuid);
    const title = firstText(job, ["name", "title"]);
    const url = firstText(job, ["postingUrl", "ref", "url"]);
    if (!id || !title || !url) throw new Error("Missing job identity/title/URL: snapshot is incomplete");
    const jobAd = job.jobAd && typeof job.jobAd === "object" ? job.jobAd as Record<string, unknown> : {};
    const sections = jobAd.sections && typeof jobAd.sections === "object" ? jobAd.sections as Record<string, unknown> : {};
    return [advert(
      organisationName,
      "SmartRecruiters",
      id,
      title,
      url,
      null,
      text(sections.jobDescription) ? stripHtml(text(sections.jobDescription)!) : null,
      smartRecruitersLocation(job.location),
      text(job.releasedDate) ?? text(job.updatedDate),
      mapping.evidenceUrl,
    )];
  });
  return { adverts, excludedUnlisted: 0 };
}

function parseRecruitee(
  organisationName: string,
  mapping: DirectBoardMapping,
  body: string,
): { adverts: BoardAdvert[]; excludedUnlisted: number } {
  const payload = parseJson(body) as { offers?: unknown; jobs?: unknown };
  const jobs = Array.isArray(payload.offers)
    ? payload.offers
    : Array.isArray(payload.jobs)
      ? payload.jobs
      : [];
  if (!Array.isArray(jobs)) throw new Error("Recruitee response did not contain an offers array");
  const adverts = jobs.flatMap((raw): BoardAdvert[] => {
    if (!raw || typeof raw !== "object") throw new Error("Malformed offer entry: snapshot is incomplete");
    const job = raw as Record<string, unknown>;
    const id = identifier(job.id);
    const title = firstText(job, ["title", "name"]);
    const url = firstText(job, ["careers_url", "url", "web_url"]);
    if (!id || !title || !url) throw new Error("Missing job identity/title/URL: snapshot is incomplete");
    const location = firstText(job, ["location", "city", "country"]);
    return [advert(
      organisationName,
      "Recruitee",
      id,
      title,
      url,
      firstText(job, ["apply_url", "careers_url", "url"]),
      text(job.description) ? stripHtml(text(job.description)!) : null,
      location,
      firstText(job, ["created_at", "published_at", "updated_at"]),
      mapping.evidenceUrl,
    )];
  });
  return { adverts, excludedUnlisted: 0 };
}

function xmlValue(block: string, tag: string): string | null {
  const escapedTag = tag.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = block.match(new RegExp(`<${escapedTag}\\b[^>]*>([\\s\\S]*?)<\\/${escapedTag}>`, "i"));
  return match?.[1] ? stripXml(match[1]) : null;
}

function parsePersonio(
  organisationName: string,
  mapping: DirectBoardMapping,
  body: string,
): { adverts: BoardAdvert[]; excludedUnlisted: number } {
  const positions = body.match(/<position\b[\s\S]*?<\/position>/gi) ?? [];
  if (positions.length === 0) throw new Error("Personio response did not contain position entries");
  const adverts = positions.flatMap((entry): BoardAdvert[] => {
    const id = xmlValue(entry, "id");
    const title = xmlValue(entry, "name");
    if (!id || !title) throw new Error("Missing job identity/title: snapshot is incomplete");
    const url = `https://${new URL(mapping.evidenceUrl).hostname}/job/${encodeURIComponent(id)}`;
    const location = [xmlValue(entry, "office"), xmlValue(entry, "subcompany")]
      .filter(Boolean)
      .join(", ") || null;
    return [advert(
      organisationName,
      "Personio",
      id,
      title,
      url,
      url,
      xmlValue(entry, "jobDescriptions"),
      location,
      xmlValue(entry, "createdAt"),
      mapping.evidenceUrl,
    )];
  });
  return { adverts, excludedUnlisted: 0 };
}

export async function fetchDirectEmployerBoardCore(
  organisationName: string,
  provider: string | null | undefined,
  savedCareersUrl: string | null | undefined,
  fetchPublicApiPage: (url: string, deadlineMs: number, maxBytes: number) => Promise<CompanySiteFetchResult>,
  options: { deadlineMs?: number; offset?: number } = {},
): Promise<DirectBoardScan> {
  const mapping = parseDirectBoardMapping(provider, savedCareersUrl);
  if (!mapping) {
    return {
      adverts: [],
      mapping: null,
      complete: false,
      transientFailure: false,
      failureClass: "permanent",
      error: "saved careers URL is not a validated supported employer board",
      pagesFetched: 0,
      advertsExtracted: 0,
      excludedUnlisted: 0,
    };
  }
  const deadlineMs = options.deadlineMs ?? Date.now() + 25_000;
  const fetchPage = (url: string) => fetchPublicApiPage(
    url,
    deadlineMs,
    2_000_000,
  );
  const offset = Math.max(0, Math.floor(options.offset ?? 0));
  const firstUrl = mapping.provider === "Lever" ? mapping.feedUrl.replace(/skip=0$/, `skip=${offset}`) : mapping.feedUrl;
  const result = await fetchPage(firstUrl);
  if (!result.ok) {
    return {
      adverts: [],
      mapping,
      complete: false,
      transientFailure: result.failureClass !== "permanent",
      failureClass: result.failureClass ?? "temporary",
      retryAt: result.retryAt,
      error: result.reason,
      pagesFetched: 0,
      advertsExtracted: 0,
      excludedUnlisted: 0,
    };
  }
  if (result.status < 200 || result.status >= 300) {
    return {
      adverts: [],
      mapping,
      complete: false,
      transientFailure: result.status === 403 || result.status === 429 || result.status >= 500,
      failureClass: result.status === 404 ? "permanent" : "temporary",
      error: `direct board HTTP ${result.status}`,
      pagesFetched: 1,
      advertsExtracted: 0,
      excludedUnlisted: 0,
    };
  }
  try {
    let parsed = mapping.provider === "Ashby"
      ? parseAshby(organisationName, mapping, result.body)
      : mapping.provider === "Greenhouse"
        ? parseGreenhouse(organisationName, mapping, result.body)
        : mapping.provider === "Lever"
          ? parseLever(organisationName, mapping, result.body)
          : mapping.provider === "SmartRecruiters"
            ? parseSmartRecruiters(organisationName, mapping, result.body)
            : mapping.provider === "Recruitee"
              ? parseRecruitee(organisationName, mapping, result.body)
              : parsePersonio(organisationName, mapping, result.body);
    let pagesFetched = 1;
    let paginationComplete = true;
    let nextOffset: number | undefined;
    if (mapping.provider === "Lever") {
      const allAdverts = [...parsed.adverts];
      let skip = offset + allAdverts.length;
      while (parsed.adverts.length >= 100 && pagesFetched < 10 && Date.now() < deadlineMs) {
        const nextUrl = `${mapping.feedUrl.split("&skip=")[0]}&skip=${skip}`;
        const next = await fetchPage(nextUrl);
        if (!next.ok || next.status < 200 || next.status >= 300) {
          return {
            adverts: allAdverts,
            nextOffset: skip,
            mapping,
            complete: false,
            transientFailure: next.ok ? next.status >= 500 || next.status === 429 : next.failureClass !== "permanent",
            failureClass: next.ok ? "temporary" : next.failureClass ?? "temporary",
            retryAt: next.ok ? undefined : next.retryAt,
            error: next.ok ? `direct board HTTP ${next.status}` : next.reason,
            pagesFetched,
            advertsExtracted: allAdverts.length,
            excludedUnlisted: 0,
          };
        }
        parsed = parseLever(organisationName, mapping, next.body);
        allAdverts.push(...parsed.adverts);
        skip += parsed.adverts.length;
        pagesFetched++;
        if (parsed.adverts.length === 0) break;
      }
      if (parsed.adverts.length >= 100 && (pagesFetched >= 10 || Date.now() >= deadlineMs)) {
        paginationComplete = false;
        nextOffset = skip;
      }
      parsed = { adverts: allAdverts, excludedUnlisted: 0 };
    }
    return {
      adverts: parsed.adverts,
      mapping,
      complete: paginationComplete,
      nextOffset,
      transientFailure: !paginationComplete,
      failureClass: paginationComplete ? null : "temporary",
      error: paginationComplete ? undefined : "Lever pagination limit or deadline reached",
      pagesFetched,
      advertsExtracted: parsed.adverts.length,
      excludedUnlisted: parsed.excludedUnlisted,
    };
  } catch (error) {
    return {
      adverts: [],
      mapping,
      complete: false,
      transientFailure: true,
      failureClass: "temporary",
      error: error instanceof Error ? error.message : "direct board parse failed",
      pagesFetched: 1,
      advertsExtracted: 0,
      excludedUnlisted: 0,
    };
  }
}
