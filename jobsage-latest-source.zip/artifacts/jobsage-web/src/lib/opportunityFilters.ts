export const UK_REGIONS = [
  "East of England", "East Midlands", "London", "North East", "North West", "South East",
  "South West", "West Midlands", "Yorkshire and the Humber", "Northern Ireland", "Scotland",
  "Wales", "National / Multiple Regions",
] as const;

export type OpportunityFilterRole = {
  targetRegions?: string[] | null;
};

export type RankedOpportunity = {
  recommended?: boolean;
  aiScore?: number | null;
  matchScore: number;
};

export type OpportunitySource = "job_board" | "company_site" | null | undefined;

export type OpportunityApplyAction = {
  destinationUrl: string;
  label: string;
  usesWebsiteFallback: boolean;
};

export function shouldShowSendCv(sendCvEligible: boolean | null | undefined): boolean {
  return sendCvEligible === true;
}

export type VacancyLinkStatus = "none" | "live" | "dead" | "unverified" | "inconclusive" | "stale";

export function canSendCvForVacancy({
  sendCvEligible,
  applyUrl,
  linkVerified,
  linkStatus,
}: {
  sendCvEligible?: boolean | null;
  applyUrl?: string | null;
  linkVerified?: boolean | null;
  linkStatus?: VacancyLinkStatus | null;
}): boolean {
  // Older /roles responses expose linkVerified but not linkStatus. Treat a
  // verified link as live so the Send CV action is not hidden on the Send CV
  // tab while the apply route remains independently usable.
  const effectiveStatus = linkStatus ?? (applyUrl ? (linkVerified ? "live" : "unverified") : "none");
  return shouldShowSendCv(sendCvEligible) && (effectiveStatus === "none" || effectiveStatus === "live");
}

export function canQueueSendCvForVacancy({
  applyUrl,
  linkVerified,
  linkStatus,
}: {
  applyUrl?: string | null;
  linkVerified?: boolean | null;
  linkStatus?: VacancyLinkStatus | null;
}): boolean {
  // No contact email is needed up front: the server stores outreach as pending
  // until a verified employer recipient becomes available. Vacancy liveness is
  // still required for vacancy-specific CV submissions.
  const effectiveStatus = linkStatus ?? (applyUrl ? (linkVerified ? "live" : "unverified") : "none");
  return applyUrl ? effectiveStatus === "live" : effectiveStatus === "none";
}

function isDisallowedSendCvApplyUrl(url: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return ["linkedin.com", "indeed.com"].some(
      (domain) => host === domain || host.endsWith(`.${domain}`),
    );
  } catch {
    return true;
  }
}

export function hasUsableSendCvApplyRoute({
  applyUrl,
  linkVerified,
  linkStatus,
}: {
  applyUrl?: string | null;
  linkVerified?: boolean | null;
  linkStatus?: VacancyLinkStatus | null;
}): boolean {
  const effectiveStatus = linkStatus ?? (linkVerified ? "live" : "unverified");
  return !!applyUrl && effectiveStatus === "live" && linkVerified === true && !isDisallowedSendCvApplyUrl(applyUrl);
}

export const CONSIDER_MIN_SCORE = 40;

export function getOpportunityApplyAction({
  sourceType,
  applyUrl,
  contactWebsite,
}: {
  sourceType: OpportunitySource;
  applyUrl?: string | null;
  contactWebsite?: string | null;
}): OpportunityApplyAction | null {
  if (applyUrl) {
    return {
      destinationUrl: applyUrl,
      label: sourceType === "company_site" ? "Apply on company's website" : "Apply Via Job Board",
      usesWebsiteFallback: false,
    };
  }

  // A vacancy must keep the application route it was discovered from. An
  // employer website is not a substitute for a missing company-site or
  // job-board vacancy URL.
  return null;
}

export function opportunityScore(role: RankedOpportunity): number {
  return role.aiScore ?? role.matchScore;
}

export function groupRankedOpportunities<T extends RankedOpportunity>(roles: T[]): {
  recommended: T[];
  consider: T[];
  remaining: T[];
} {
  const recommended = roles.filter((role) => role.recommended === true).slice(0, 5);
  const recommendedSet = new Set(recommended);
  const consider = roles
    .filter((role) => !recommendedSet.has(role) && opportunityScore(role) >= CONSIDER_MIN_SCORE)
    .slice(0, 5);
  const considerSet = new Set(consider);
  const remaining = roles.filter((role) => !recommendedSet.has(role) && !considerSet.has(role));
  return { recommended, consider, remaining };
}

function regionKey(region: string): string {
  return region.trim().toLowerCase().replace(/\s+/g, " ");
}

export function hasRegionOverlap(targetRegions: string[] | null | undefined, selectedRegions: string[]): boolean {
  if (selectedRegions.length === 0 || !targetRegions || targetRegions.length === 0) return true;
  const selected = new Set(selectedRegions.map(regionKey));
  if (targetRegions.some((region) => regionKey(region) === regionKey("National / Multiple Regions"))) return true;
  return targetRegions.some((region) => selected.has(regionKey(region)));
}

export function filterOpportunities<T extends OpportunityFilterRole>(
  roles: T[],
  filters: { selectedRegions: string[] },
): T[] {
  return roles.filter((role) => hasRegionOverlap(role.targetRegions, filters.selectedRegions));
}

export function filterSendCvVacancies<T extends { role: { employer: string; title: string; location: string } }>(
  vacancies: T[],
  search: string,
): T[] {
  const query = search.trim().toLowerCase();
  if (!query) return vacancies;
  return vacancies.filter(({ role }) =>
    [role.employer, role.title, role.location].some((value) => value?.toLowerCase().includes(query)),
  );
}

export function filterSendCvSponsors<T extends { sendCvEligible?: boolean | null }>(
  companies: T[],
): T[] {
  return companies.filter((company) => shouldShowSendCv(company.sendCvEligible));
}
